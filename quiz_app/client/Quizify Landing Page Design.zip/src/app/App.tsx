import { useState, useEffect } from "react";
import {
  Zap, Users, BarChart3, Plus, ChevronRight, ChevronLeft,
  Trophy, Clock, CheckCircle, XCircle, GripVertical, Eye,
  Upload, Star, Medal, Crown, ArrowLeft, Send, Sparkles,
  Mail, Lock, User, Github, EyeOff, AtSign, AlertCircle
} from "lucide-react";

type Screen = "landing" | "create" | "quiz" | "leaderboard" | "login" | "register";

// ─── Data ───────────────────────────────────────────────────────────────────

const QUESTIONS = [
  {
    id: 1,
    text: "What is the capital of France?",
    options: ["London", "Berlin", "Paris", "Madrid"],
    correct: 2,
    image: null,
  },
  {
    id: 2,
    text: "Which planet is known as the Red Planet?",
    options: ["Venus", "Mars", "Jupiter", "Saturn"],
    correct: 1,
    image: null,
  },
  {
    id: 3,
    text: "What is 2 + 2 × 2?",
    options: ["6", "8", "4", "10"],
    correct: 0,
    image: null,
  },
];

const LEADERBOARD_DATA = [
  { id: 1, name: "Alex Rivera", score: 2850, time: "1m 42s", avatar: "AR" },
  { id: 2, name: "Jordan Kim", score: 2600, time: "1m 58s", avatar: "JK" },
  { id: 3, name: "Sam Patel", score: 2400, time: "2m 05s", avatar: "SP" },
  { id: 4, name: "You", score: 2200, time: "2m 14s", avatar: "ME", isMe: true },
  { id: 5, name: "Chris Wong", score: 1950, time: "2m 31s", avatar: "CW" },
  { id: 6, name: "Taylor Brooks", score: 1700, time: "2m 48s", avatar: "TB" },
  { id: 7, name: "Morgan Lee", score: 1450, time: "3m 02s", avatar: "ML" },
];

const PARTICIPANTS = [
  { name: "Alex R.", answered: true },
  { name: "Jordan K.", answered: true },
  { name: "Sam P.", answered: false },
  { name: "You", answered: false, isMe: true },
  { name: "Chris W.", answered: true },
];

const DRAFT_QUESTIONS = [
  { id: 1, type: "Multiple Choice", text: "What is photosynthesis?", options: 4 },
  { id: 2, type: "True / False", text: "The sun is a star.", options: 2 },
  { id: 3, type: "Multiple Choice", text: "Which element has symbol Au?", options: 4 },
];

// ─── Confetti ────────────────────────────────────────────────────────────────

function Confetti() {
  const pieces = Array.from({ length: 48 }, (_, i) => ({
    id: i,
    left: `${Math.random() * 100}%`,
    delay: `${Math.random() * 3}s`,
    duration: `${2.5 + Math.random() * 2}s`,
    color: ["#6C63FF", "#FFD700", "#4CAF50", "#FF6B9D", "#00BCD4"][i % 5],
    size: `${6 + Math.random() * 8}px`,
    rotate: `${Math.random() * 360}deg`,
  }));

  return (
    <div className="pointer-events-none absolute inset-0 overflow-hidden">
      {pieces.map((p) => (
        <div
          key={p.id}
          className="absolute -top-4 rounded-sm"
          style={{
            left: p.left,
            width: p.size,
            height: p.size,
            background: p.color,
            transform: `rotate(${p.rotate})`,
            animation: `confettiFall ${p.duration} ${p.delay} linear infinite`,
            opacity: 0.85,
          }}
        />
      ))}
      <style>{`
        @keyframes confettiFall {
          0%   { transform: translateY(-20px) rotate(0deg); opacity: 1; }
          100% { transform: translateY(110vh) rotate(720deg); opacity: 0; }
        }
      `}</style>
    </div>
  );
}

// ─── Nav ─────────────────────────────────────────────────────────────────────

function Nav({ onNavigate }: { onNavigate: (s: Screen) => void }) {
  return (
    <nav className="fixed top-0 inset-x-0 z-50 flex items-center justify-between px-8 py-4 bg-white/80 backdrop-blur-md border-b border-[rgba(108,99,255,0.1)] shadow-sm">
      <button
        onClick={() => onNavigate("landing")}
        className="flex items-center gap-2 group"
      >
        <div className="w-8 h-8 rounded-lg bg-[#6C63FF] flex items-center justify-center shadow-md shadow-[#6C63FF]/30">
          <Zap size={16} className="text-white" />
        </div>
        <span className="font-extrabold text-xl text-[#1a1535] tracking-tight" style={{ fontFamily: "'Nunito', sans-serif" }}>
          Quizify
        </span>
      </button>
      <div className="flex items-center gap-3">
        <button
          onClick={() => onNavigate("quiz")}
          className="text-sm font-semibold text-[#6b6a8a] hover:text-[#6C63FF] transition-colors px-3 py-1.5"
          style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}
        >
          Live Demo
        </button>
        <button
          onClick={() => onNavigate("leaderboard")}
          className="text-sm font-semibold text-[#6b6a8a] hover:text-[#6C63FF] transition-colors px-3 py-1.5"
          style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}
        >
          Leaderboard
        </button>
        <button
          onClick={() => onNavigate("login")}
          className="text-sm font-semibold text-[#6b6a8a] hover:text-[#6C63FF] transition-colors px-3 py-1.5 border border-[rgba(108,99,255,0.2)] rounded-xl hover:border-[#6C63FF]/50"
          style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}
        >
          Log In
        </button>
        <button
          onClick={() => onNavigate("register")}
          className="text-sm font-semibold bg-[#6C63FF] text-white px-5 py-2 rounded-xl hover:bg-[#5550e8] transition-all shadow-md shadow-[#6C63FF]/25 active:scale-95"
          style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}
        >
          Get Started
        </button>
      </div>
    </nav>
  );
}

// ─── Landing ─────────────────────────────────────────────────────────────────

function Landing({ onNavigate }: { onNavigate: (s: Screen) => void }) {
  return (
    <div className="min-h-screen bg-[#f8f7ff]" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>
      {/* Hero */}
      <section className="relative overflow-hidden pt-32 pb-24 px-6">
        {/* Gradient backdrop */}
        <div
          className="absolute inset-0 -z-10"
          style={{
            background: "linear-gradient(135deg, #6C63FF 0%, #4f46e5 40%, #2563eb 100%)",
          }}
        />
        {/* Decorative blobs */}
        <div className="absolute -top-20 -right-20 w-96 h-96 rounded-full bg-white/5 blur-3xl -z-10" />
        <div className="absolute -bottom-32 -left-20 w-96 h-96 rounded-full bg-[#4CAF50]/10 blur-3xl -z-10" />
        {/* Floating circles */}
        <div className="absolute top-16 right-1/4 w-3 h-3 rounded-full bg-white/30 animate-pulse" />
        <div className="absolute top-32 right-1/3 w-2 h-2 rounded-full bg-[#4CAF50]/60" />
        <div className="absolute bottom-16 left-1/4 w-4 h-4 rounded-full bg-white/20 animate-bounce" style={{ animationDuration: "3s" }} />

        <div className="max-w-4xl mx-auto text-center">
          <div className="inline-flex items-center gap-2 bg-white/15 backdrop-blur-sm text-white text-xs font-semibold px-4 py-2 rounded-full mb-8 border border-white/20">
            <Sparkles size={12} />
            Real-time quiz platform for everyone
          </div>
          <h1
            className="text-6xl md:text-7xl font-extrabold text-white mb-6 leading-none tracking-tight"
            style={{ fontFamily: "'Nunito', sans-serif" }}
          >
            Quizify
          </h1>
          <p className="text-xl md:text-2xl text-white/80 font-medium mb-12 max-w-2xl mx-auto leading-relaxed">
            Create and participate in quizzes in real-time
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <button
              onClick={() => onNavigate("create")}
              className="group flex items-center justify-center gap-2 bg-white text-[#6C63FF] font-bold px-8 py-4 rounded-2xl text-base hover:bg-[#f0efff] transition-all shadow-xl active:scale-95"
            >
              Get Started
              <ChevronRight size={18} className="group-hover:translate-x-1 transition-transform" />
            </button>
            <button
              onClick={() => onNavigate("login")}
              className="flex items-center justify-center gap-2 bg-white/10 backdrop-blur-sm text-white font-bold px-8 py-4 rounded-2xl text-base border border-white/25 hover:bg-white/20 transition-all active:scale-95"
            >
              Log In
            </button>
          </div>
          {/* Stats row */}
          <div className="flex justify-center gap-10 mt-16 text-white">
            {[["12K+", "Quizzes"], ["48K+", "Players"], ["98%", "Satisfaction"]].map(([n, l]) => (
              <div key={l} className="text-center">
                <div className="text-3xl font-extrabold" style={{ fontFamily: "'Nunito', sans-serif" }}>{n}</div>
                <div className="text-white/60 text-sm font-medium mt-1">{l}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Feature Cards */}
      <section className="py-24 px-6 max-w-5xl mx-auto">
        <div className="text-center mb-14">
          <h2 className="text-4xl font-extrabold text-[#1a1535] mb-4" style={{ fontFamily: "'Nunito', sans-serif" }}>
            Everything you need
          </h2>
          <p className="text-[#6b6a8a] text-lg max-w-xl mx-auto">
            From creating engaging quizzes to tracking your performance — Quizify has it all.
          </p>
        </div>
        <div className="grid md:grid-cols-3 gap-8">
          {[
            {
              icon: <Zap size={28} className="text-[#6C63FF]" />,
              title: "Create Quizzes",
              desc: "Build beautiful quizzes with multiple question types, images, and time limits in minutes.",
              bg: "bg-[#f0efff]",
              action: () => onNavigate("create"),
            },
            {
              icon: <Users size={28} className="text-[#4CAF50]" />,
              title: "Join Games",
              desc: "Join live quiz sessions with a simple game code. Compete in real-time with players worldwide.",
              bg: "bg-[#f0faf0]",
              action: () => onNavigate("quiz"),
            },
            {
              icon: <BarChart3 size={28} className="text-[#FF6B9D]" />,
              title: "Track Results",
              desc: "Detailed analytics, leaderboards, and performance tracking to see how you stack up.",
              bg: "bg-[#fff0f6]",
              action: () => onNavigate("leaderboard"),
            },
          ].map((f) => (
            <button
              key={f.title}
              onClick={f.action}
              className="group bg-white rounded-3xl p-8 shadow-sm hover:shadow-xl border border-[rgba(108,99,255,0.08)] transition-all duration-300 hover:-translate-y-1 text-left w-full"
            >
              <div className={`w-14 h-14 rounded-2xl ${f.bg} flex items-center justify-center mb-6`}>
                {f.icon}
              </div>
              <h3 className="text-xl font-bold text-[#1a1535] mb-3" style={{ fontFamily: "'Nunito', sans-serif" }}>
                {f.title}
              </h3>
              <p className="text-[#6b6a8a] leading-relaxed text-sm">{f.desc}</p>
              <div className="mt-5 flex items-center gap-1 text-[#6C63FF] text-sm font-semibold opacity-0 group-hover:opacity-100 transition-opacity">
                Explore <ChevronRight size={14} />
              </div>
            </button>
          ))}
        </div>
      </section>

      {/* CTA Banner */}
      <section className="pb-24 px-6 max-w-5xl mx-auto">
        <div
          className="rounded-3xl p-12 text-center relative overflow-hidden"
          style={{ background: "linear-gradient(135deg, #6C63FF 0%, #2563eb 100%)" }}
        >
          <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNDAiIGhlaWdodD0iNDAiIHZpZXdCb3g9IjAgMCA0MCA0MCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48Y2lyY2xlIGN4PSIyMCIgY3k9IjIwIiByPSIxLjUiIGZpbGw9InJnYmEoMjU1LDI1NSwyNTUsMC4xKSIvPjwvc3ZnPg==')] opacity-30" />
          <h2 className="text-3xl font-extrabold text-white mb-3 relative" style={{ fontFamily: "'Nunito', sans-serif" }}>
            Ready to quiz smarter?
          </h2>
          <p className="text-white/70 mb-8 text-base relative">Join thousands of educators and learners today.</p>
          <button
            onClick={() => onNavigate("create")}
            className="relative bg-white text-[#6C63FF] font-bold px-10 py-4 rounded-2xl hover:bg-[#f0efff] transition-all shadow-xl active:scale-95"
          >
            Start for free
          </button>
        </div>
      </section>
    </div>
  );
}

// ─── Quiz Creator ─────────────────────────────────────────────────────────────

function QuizCreator({ onNavigate }: { onNavigate: (s: Screen) => void }) {
  const [step, setStep] = useState(1);
  const [timeLimit, setTimeLimit] = useState(30);
  const [category, setCategory] = useState("Science");

  const steps = ["Basic Info", "Questions", "Preview & Publish"];

  return (
    <div className="min-h-screen bg-[#f8f7ff] pt-24 pb-16 px-6" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>
      <div className="max-w-2xl mx-auto">
        {/* Progress bar */}
        <div className="mb-10">
          <div className="flex justify-between mb-3">
            {steps.map((s, i) => (
              <button
                key={s}
                onClick={() => setStep(i + 1)}
                className={`text-xs font-semibold transition-colors ${step > i ? "text-[#6C63FF]" : step === i + 1 ? "text-[#1a1535]" : "text-[#6b6a8a]"}`}
              >
                Step {i + 1}: {s}
              </button>
            ))}
          </div>
          <div className="h-2 bg-[#ededf5] rounded-full overflow-hidden">
            <div
              className="h-full rounded-full transition-all duration-500"
              style={{
                width: `${(step / 3) * 100}%`,
                background: "linear-gradient(90deg, #6C63FF, #4f46e5)",
              }}
            />
          </div>
          <div className="flex justify-between mt-2">
            {steps.map((_, i) => (
              <div
                key={i}
                className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold transition-all -mt-5 border-2 ${
                  step > i
                    ? "bg-[#6C63FF] border-[#6C63FF] text-white"
                    : step === i + 1
                    ? "bg-white border-[#6C63FF] text-[#6C63FF]"
                    : "bg-white border-[#ededf5] text-[#6b6a8a]"
                }`}
              >
                {step > i ? <CheckCircle size={12} /> : i + 1}
              </div>
            ))}
          </div>
        </div>

        {/* Step 1 */}
        {step === 1 && (
          <div className="bg-white rounded-3xl shadow-sm border border-[rgba(108,99,255,0.08)] p-8">
            <h2 className="text-2xl font-extrabold text-[#1a1535] mb-1" style={{ fontFamily: "'Nunito', sans-serif" }}>
              Basic Information
            </h2>
            <p className="text-[#6b6a8a] text-sm mb-8">Set up your quiz details and preferences.</p>

            <div className="space-y-6">
              <div>
                <label className="block text-sm font-semibold text-[#1a1535] mb-2">Quiz Title</label>
                <input
                  type="text"
                  defaultValue="World Geography Challenge"
                  className="w-full bg-[#f4f3ff] border border-[rgba(108,99,255,0.12)] rounded-xl px-4 py-3 text-[#1a1535] text-sm focus:outline-none focus:ring-2 focus:ring-[#6C63FF]/30 focus:border-[#6C63FF] transition-all"
                  placeholder="Enter quiz title..."
                />
              </div>
              <div>
                <label className="block text-sm font-semibold text-[#1a1535] mb-2">Description</label>
                <textarea
                  rows={3}
                  defaultValue="Test your knowledge of world capitals, geography, and landmarks."
                  className="w-full bg-[#f4f3ff] border border-[rgba(108,99,255,0.12)] rounded-xl px-4 py-3 text-[#1a1535] text-sm focus:outline-none focus:ring-2 focus:ring-[#6C63FF]/30 focus:border-[#6C63FF] transition-all resize-none"
                  placeholder="Describe your quiz..."
                />
              </div>
              <div>
                <label className="block text-sm font-semibold text-[#1a1535] mb-2">Category</label>
                <select
                  value={category}
                  onChange={(e) => setCategory(e.target.value)}
                  className="w-full bg-[#f4f3ff] border border-[rgba(108,99,255,0.12)] rounded-xl px-4 py-3 text-[#1a1535] text-sm focus:outline-none focus:ring-2 focus:ring-[#6C63FF]/30 focus:border-[#6C63FF] transition-all"
                >
                  {["Science", "History", "Geography", "Arts", "Technology", "Sports", "Entertainment"].map((c) => (
                    <option key={c}>{c}</option>
                  ))}
                </select>
              </div>
              <div>
                <div className="flex justify-between mb-2">
                  <label className="block text-sm font-semibold text-[#1a1535]">Time Limit per Question</label>
                  <span className="text-sm font-bold text-[#6C63FF]">{timeLimit}s</span>
                </div>
                <input
                  type="range"
                  min={10}
                  max={120}
                  step={5}
                  value={timeLimit}
                  onChange={(e) => setTimeLimit(Number(e.target.value))}
                  className="w-full accent-[#6C63FF] h-2 rounded-full"
                />
                <div className="flex justify-between text-xs text-[#6b6a8a] mt-1">
                  <span>10s</span><span>30s</span><span>60s</span><span>120s</span>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Step 2 */}
        {step === 2 && (
          <div className="bg-white rounded-3xl shadow-sm border border-[rgba(108,99,255,0.08)] p-8">
            <div className="flex items-center justify-between mb-1">
              <h2 className="text-2xl font-extrabold text-[#1a1535]" style={{ fontFamily: "'Nunito', sans-serif" }}>
                Questions
              </h2>
              <span className="text-xs font-semibold bg-[#f0efff] text-[#6C63FF] px-3 py-1 rounded-full">
                {DRAFT_QUESTIONS.length} added
              </span>
            </div>
            <p className="text-[#6b6a8a] text-sm mb-8">Add and organize your quiz questions.</p>

            <div className="space-y-3 mb-6">
              {DRAFT_QUESTIONS.map((q, i) => (
                <div
                  key={q.id}
                  className="flex items-center gap-4 p-4 bg-[#f8f7ff] rounded-2xl border border-[rgba(108,99,255,0.08)] group hover:border-[#6C63FF]/25 transition-all"
                >
                  <GripVertical size={16} className="text-[#c4c2e8] cursor-grab shrink-0" />
                  <div className="w-7 h-7 rounded-lg bg-[#6C63FF]/10 flex items-center justify-center text-xs font-bold text-[#6C63FF] shrink-0">
                    {i + 1}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-semibold text-[#1a1535] truncate">{q.text}</p>
                    <p className="text-xs text-[#6b6a8a] mt-0.5">{q.options} options</p>
                  </div>
                  <span
                    className={`text-xs font-semibold px-2.5 py-1 rounded-full shrink-0 ${
                      q.type === "True / False"
                        ? "bg-[#f0faf0] text-[#4CAF50]"
                        : "bg-[#f0efff] text-[#6C63FF]"
                    }`}
                  >
                    {q.type}
                  </span>
                </div>
              ))}
            </div>

            <button className="w-full flex items-center justify-center gap-2 border-2 border-dashed border-[#6C63FF]/30 text-[#6C63FF] font-semibold py-4 rounded-2xl hover:bg-[#f0efff] hover:border-[#6C63FF]/60 transition-all text-sm">
              <Plus size={18} />
              Add Question
            </button>
          </div>
        )}

        {/* Step 3 */}
        {step === 3 && (
          <div className="space-y-5">
            <div className="bg-white rounded-3xl shadow-sm border border-[rgba(108,99,255,0.08)] p-8">
              <div className="flex items-center gap-3 mb-6">
                <div className="w-12 h-12 rounded-2xl bg-[#f0efff] flex items-center justify-center">
                  <Eye size={22} className="text-[#6C63FF]" />
                </div>
                <div>
                  <h2 className="text-xl font-extrabold text-[#1a1535]" style={{ fontFamily: "'Nunito', sans-serif" }}>
                    Preview &amp; Publish
                  </h2>
                  <p className="text-[#6b6a8a] text-xs">Everything looks good? Hit publish!</p>
                </div>
              </div>

              {/* Mini quiz card */}
              <div
                className="rounded-2xl p-6 mb-6 text-white relative overflow-hidden"
                style={{ background: "linear-gradient(135deg, #6C63FF, #2563eb)" }}
              >
                <div className="text-xs font-semibold uppercase tracking-wider text-white/60 mb-2">Geography</div>
                <h3 className="text-xl font-extrabold mb-1" style={{ fontFamily: "'Nunito', sans-serif" }}>
                  World Geography Challenge
                </h3>
                <p className="text-white/70 text-sm mb-4">
                  Test your knowledge of world capitals, geography, and landmarks.
                </p>
                <div className="flex gap-4 text-xs text-white/80">
                  <span className="flex items-center gap-1"><Clock size={12} />{timeLimit}s / question</span>
                  <span className="flex items-center gap-1"><Star size={12} />3 questions</span>
                </div>
              </div>

              {/* Questions preview */}
              <div className="space-y-2">
                {DRAFT_QUESTIONS.map((q, i) => (
                  <div key={q.id} className="flex items-center gap-3 py-3 border-b border-[rgba(108,99,255,0.06)] last:border-0">
                    <span className="text-xs font-bold text-[#6b6a8a] w-5 shrink-0">{i + 1}.</span>
                    <span className="text-sm text-[#1a1535] font-medium flex-1">{q.text}</span>
                    <span className="text-xs text-[#6b6a8a]">{q.options} opts</span>
                  </div>
                ))}
              </div>
            </div>

            <button
              onClick={() => onNavigate("quiz")}
              className="w-full flex items-center justify-center gap-3 text-white font-bold py-5 rounded-2xl text-base shadow-xl shadow-[#6C63FF]/25 hover:opacity-90 transition-all active:scale-[0.98]"
              style={{ background: "linear-gradient(135deg, #6C63FF, #4f46e5)" }}
            >
              <Upload size={20} />
              Publish Quiz
            </button>
          </div>
        )}

        {/* Navigation */}
        <div className="flex justify-between mt-8">
          <button
            onClick={() => step > 1 ? setStep(step - 1) : onNavigate("landing")}
            className="flex items-center gap-2 text-sm font-semibold text-[#6b6a8a] hover:text-[#1a1535] transition-colors px-5 py-3 rounded-xl hover:bg-white"
          >
            <ChevronLeft size={16} />
            {step > 1 ? "Back" : "Landing"}
          </button>
          {step < 3 && (
            <button
              onClick={() => setStep(step + 1)}
              className="flex items-center gap-2 text-sm font-bold bg-[#6C63FF] text-white px-6 py-3 rounded-xl hover:bg-[#5550e8] transition-all shadow-md shadow-[#6C63FF]/25 active:scale-95"
            >
              Next
              <ChevronRight size={16} />
            </button>
          )}
        </div>
      </div>
    </div>
  );
}

// ─── Quiz Participation ───────────────────────────────────────────────────────

function QuizScreen({ onNavigate }: { onNavigate: (s: Screen) => void }) {
  const [currentQ, setCurrentQ] = useState(0);
  const [selected, setSelected] = useState<number | null>(null);
  const [submitted, setSubmitted] = useState(false);
  const [timeLeft, setTimeLeft] = useState(28);
  const [points, setPoints] = useState(1200);

  const q = QUESTIONS[currentQ];
  const letters = ["A", "B", "C", "D"];

  useEffect(() => {
    if (submitted) return;
    const t = setInterval(() => setTimeLeft((p) => (p > 0 ? p - 1 : 0)), 1000);
    return () => clearInterval(t);
  }, [submitted, currentQ]);

  const handleSubmit = () => {
    if (selected === null) return;
    setSubmitted(true);
    if (selected === q.correct) setPoints((p) => p + 350);
  };

  const handleNext = () => {
    if (currentQ < QUESTIONS.length - 1) {
      setCurrentQ((p) => p + 1);
      setSelected(null);
      setSubmitted(false);
      setTimeLeft(28);
    } else {
      onNavigate("leaderboard");
    }
  };

  const timerPct = (timeLeft / 28) * 100;
  const timerColor = timeLeft > 10 ? "#6C63FF" : "#ef4444";

  return (
    <div className="min-h-screen bg-[#f8f7ff] pt-16 flex flex-col" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>
      {/* Top bar */}
      <div className="bg-white border-b border-[rgba(108,99,255,0.08)] px-6 py-3 flex items-center justify-between shadow-sm">
        <div className="flex items-center gap-4">
          <button onClick={() => onNavigate("create")} className="text-[#6b6a8a] hover:text-[#6C63FF] transition-colors">
            <ArrowLeft size={18} />
          </button>
          <span className="font-bold text-[#1a1535] text-sm">World Geography Challenge</span>
        </div>
        <div className="flex items-center gap-2 bg-[#f4f3ff] px-3 py-1.5 rounded-xl">
          <span className="text-xs font-semibold text-[#6b6a8a]">Question</span>
          <span className="text-sm font-extrabold text-[#6C63FF]">{currentQ + 1}/{QUESTIONS.length}</span>
        </div>
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-1.5 text-sm font-bold text-[#4CAF50]">
            <Star size={15} className="fill-[#4CAF50]" />
            {points.toLocaleString()}
          </div>
        </div>
      </div>

      <div className="flex-1 flex gap-0">
        {/* Main question area */}
        <div className="flex-1 flex flex-col items-center justify-center px-6 py-8">
          {/* Timer */}
          <div className="mb-8 relative">
            <svg width="80" height="80" className="-rotate-90">
              <circle cx="40" cy="40" r="34" fill="none" stroke="#ededf5" strokeWidth="6" />
              <circle
                cx="40" cy="40" r="34" fill="none"
                stroke={timerColor}
                strokeWidth="6"
                strokeDasharray={`${2 * Math.PI * 34}`}
                strokeDashoffset={`${2 * Math.PI * 34 * (1 - timerPct / 100)}`}
                strokeLinecap="round"
                className="transition-all duration-1000"
              />
            </svg>
            <div
              className="absolute inset-0 flex items-center justify-center text-xl font-extrabold transition-colors"
              style={{ color: timerColor, fontFamily: "'Nunito', sans-serif" }}
            >
              {timeLeft}
            </div>
          </div>

          {/* Question card */}
          <div className="w-full max-w-xl bg-white rounded-3xl shadow-sm border border-[rgba(108,99,255,0.08)] p-8 mb-6">
            {/* Image placeholder */}
            <div className="w-full h-32 bg-gradient-to-br from-[#f0efff] to-[#e8e6ff] rounded-2xl mb-6 flex items-center justify-center">
              <span className="text-[#6b6a8a] text-sm font-medium">Image placeholder</span>
            </div>
            <p className="text-xl font-bold text-[#1a1535] text-center leading-snug" style={{ fontFamily: "'Nunito', sans-serif" }}>
              {q.text}
            </p>
          </div>

          {/* Options grid */}
          <div className="grid grid-cols-2 gap-3 w-full max-w-xl">
            {q.options.map((opt, i) => {
              let cls = "bg-white border-[rgba(108,99,255,0.12)] text-[#1a1535] hover:border-[#6C63FF]/40 hover:bg-[#f0efff]";
              if (selected === i) {
                if (!submitted) cls = "bg-[#6C63FF] border-[#6C63FF] text-white shadow-lg shadow-[#6C63FF]/25";
                else if (i === q.correct) cls = "bg-[#4CAF50] border-[#4CAF50] text-white shadow-lg shadow-[#4CAF50]/25";
                else cls = "bg-[#ef4444] border-[#ef4444] text-white shadow-lg shadow-[#ef4444]/25";
              } else if (submitted && i === q.correct) {
                cls = "bg-[#f0faf0] border-[#4CAF50] text-[#4CAF50]";
              }
              return (
                <button
                  key={i}
                  disabled={submitted}
                  onClick={() => setSelected(i)}
                  className={`flex items-center gap-3 p-4 rounded-2xl border-2 transition-all font-semibold text-sm text-left ${cls}`}
                >
                  <span
                    className={`w-8 h-8 rounded-xl flex items-center justify-center text-xs font-extrabold shrink-0 ${
                      selected === i && !submitted ? "bg-white/20" : "bg-[#f0efff] text-[#6C63FF]"
                    }`}
                  >
                    {letters[i]}
                  </span>
                  {opt}
                </button>
              );
            })}
          </div>

          {/* Submit / Next */}
          <div className="mt-6 w-full max-w-xl">
            {!submitted ? (
              <button
                onClick={handleSubmit}
                disabled={selected === null}
                className="w-full flex items-center justify-center gap-2 py-4 rounded-2xl font-bold text-sm transition-all disabled:opacity-40 disabled:cursor-not-allowed text-white shadow-lg shadow-[#6C63FF]/20 active:scale-[0.98]"
                style={{
                  background: selected !== null ? "linear-gradient(135deg, #6C63FF, #4f46e5)" : "#ededf5",
                  color: selected !== null ? "white" : "#6b6a8a",
                }}
              >
                <Send size={16} />
                Submit Answer
              </button>
            ) : (
              <button
                onClick={handleNext}
                className="w-full flex items-center justify-center gap-2 py-4 rounded-2xl font-bold text-sm text-white shadow-lg shadow-[#4CAF50]/20 active:scale-[0.98]"
                style={{ background: "linear-gradient(135deg, #4CAF50, #2e7d32)" }}
              >
                {currentQ < QUESTIONS.length - 1 ? "Next Question" : "See Results"}
                <ChevronRight size={16} />
              </button>
            )}
          </div>
        </div>

        {/* Participants sidebar */}
        <div className="hidden lg:flex flex-col w-60 border-l border-[rgba(108,99,255,0.08)] bg-white p-5">
          <h3 className="text-xs font-bold text-[#6b6a8a] uppercase tracking-wider mb-4">Players</h3>
          <div className="space-y-2">
            {PARTICIPANTS.map((p) => (
              <div
                key={p.name}
                className={`flex items-center gap-3 p-2.5 rounded-xl transition-all ${p.isMe ? "bg-[#f0efff]" : "hover:bg-[#f8f7ff]"}`}
              >
                <div
                  className={`w-8 h-8 rounded-lg flex items-center justify-center text-xs font-bold ${
                    p.isMe ? "bg-[#6C63FF] text-white" : "bg-[#ededf5] text-[#6b6a8a]"
                  }`}
                >
                  {p.name.split(" ")[0][0]}
                </div>
                <span className={`text-sm font-semibold flex-1 ${p.isMe ? "text-[#6C63FF]" : "text-[#1a1535]"}`}>
                  {p.name}
                </span>
                {p.answered ? (
                  <CheckCircle size={14} className="text-[#4CAF50]" />
                ) : (
                  <div className="w-3.5 h-3.5 rounded-full border-2 border-[#ededf5]" />
                )}
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

// ─── Leaderboard ──────────────────────────────────────────────────────────────

function Leaderboard({ onNavigate }: { onNavigate: (s: Screen) => void }) {
  const maxScore = LEADERBOARD_DATA[0].score;
  const medalColors = ["#FFD700", "#C0C0C0", "#CD7F32"];
  const medalIcons = [Crown, Medal, Medal];

  return (
    <div className="min-h-screen bg-[#f8f7ff] pt-16" style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}>
      {/* Gradient header */}
      <div
        className="relative overflow-hidden px-6 pt-12 pb-32"
        style={{ background: "linear-gradient(135deg, #6C63FF 0%, #4f46e5 50%, #2563eb 100%)" }}
      >
        <Confetti />
        <div className="relative z-10 text-center">
          <div className="inline-flex items-center justify-center w-20 h-20 rounded-3xl bg-[#FFD700]/20 backdrop-blur-sm mb-4 border border-[#FFD700]/30">
            <Trophy size={40} className="text-[#FFD700] drop-shadow-lg" />
          </div>
          <h1 className="text-4xl font-extrabold text-white mb-2" style={{ fontFamily: "'Nunito', sans-serif" }}>
            Quiz Complete!
          </h1>
          <p className="text-white/70 text-base">World Geography Challenge — Final Rankings</p>
        </div>

        {/* Top 3 podium */}
        <div className="relative z-10 flex items-end justify-center gap-4 mt-10">
          {[LEADERBOARD_DATA[1], LEADERBOARD_DATA[0], LEADERBOARD_DATA[2]].map((p, i) => {
            const rank = [2, 1, 3][i];
            const heights = ["h-24", "h-32", "h-20"];
            const MedalIcon = medalIcons[rank - 1];
            return (
              <div key={p.id} className={`flex flex-col items-center ${i === 1 ? "scale-105" : ""}`}>
                <div
                  className="w-14 h-14 rounded-2xl flex items-center justify-center text-lg font-extrabold text-white mb-2 shadow-lg"
                  style={{ background: `${medalColors[rank - 1]}33`, border: `2px solid ${medalColors[rank - 1]}66` }}
                >
                  {p.avatar}
                </div>
                <div className="text-white text-xs font-semibold mb-1">{p.name.split(" ")[0]}</div>
                <div className="text-white text-sm font-extrabold mb-2">{p.score.toLocaleString()}</div>
                <div
                  className={`w-20 ${heights[i]} rounded-t-2xl flex items-start justify-center pt-3`}
                  style={{ background: `${medalColors[rank - 1]}30`, border: `1px solid ${medalColors[rank - 1]}50` }}
                >
                  <MedalIcon size={20} style={{ color: medalColors[rank - 1] }} />
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Full rankings table */}
      <div className="px-6 -mt-6 pb-16 max-w-2xl mx-auto">
        <div className="bg-white rounded-3xl shadow-sm border border-[rgba(108,99,255,0.08)] overflow-hidden">
          <div className="grid grid-cols-12 px-5 py-3 bg-[#f8f7ff] border-b border-[rgba(108,99,255,0.06)]">
            <span className="col-span-1 text-xs font-bold text-[#6b6a8a] uppercase">#</span>
            <span className="col-span-5 text-xs font-bold text-[#6b6a8a] uppercase">Player</span>
            <span className="col-span-3 text-xs font-bold text-[#6b6a8a] uppercase">Score</span>
            <span className="col-span-3 text-xs font-bold text-[#6b6a8a] uppercase">Time</span>
          </div>
          {LEADERBOARD_DATA.map((p) => (
            <div
              key={p.id}
              className={`grid grid-cols-12 items-center px-5 py-4 border-b border-[rgba(108,99,255,0.04)] last:border-0 transition-colors ${
                p.isMe ? "bg-[#f0efff]" : "hover:bg-[#fafaff]"
              }`}
            >
              <div className="col-span-1">
                {p.id <= 3 ? (
                  <span className="text-base" style={{ color: medalColors[p.id - 1] }}>
                    {["🥇", "🥈", "🥉"][p.id - 1]}
                  </span>
                ) : (
                  <span className="text-sm font-bold text-[#6b6a8a]">{p.id}</span>
                )}
              </div>
              <div className="col-span-5 flex items-center gap-3">
                <div
                  className={`w-9 h-9 rounded-xl flex items-center justify-center text-xs font-bold ${
                    p.isMe ? "bg-[#6C63FF] text-white" : "bg-[#f0efff] text-[#6C63FF]"
                  }`}
                >
                  {p.avatar}
                </div>
                <span className={`text-sm font-semibold ${p.isMe ? "text-[#6C63FF]" : "text-[#1a1535]"}`}>
                  {p.name} {p.isMe && <span className="text-xs text-[#6b6a8a]">(You)</span>}
                </span>
              </div>
              <div className="col-span-3">
                <div className="text-sm font-bold text-[#1a1535] mb-1">{p.score.toLocaleString()}</div>
                <div className="h-1.5 bg-[#ededf5] rounded-full overflow-hidden w-16">
                  <div
                    className="h-full rounded-full transition-all"
                    style={{
                      width: `${(p.score / maxScore) * 100}%`,
                      background: p.isMe ? "#6C63FF" : "linear-gradient(90deg,#4CAF50,#2e7d32)",
                    }}
                  />
                </div>
              </div>
              <div className="col-span-3 flex items-center gap-1 text-sm text-[#6b6a8a] font-medium">
                <Clock size={12} />
                {p.time}
              </div>
            </div>
          ))}
        </div>

        <div className="flex gap-3 mt-8">
          <button
            onClick={() => onNavigate("landing")}
            className="flex-1 flex items-center justify-center gap-2 text-sm font-bold py-4 rounded-2xl border-2 border-[rgba(108,99,255,0.15)] text-[#6C63FF] hover:bg-[#f0efff] transition-all"
          >
            <ArrowLeft size={16} />
            Back to Dashboard
          </button>
          <button
            onClick={() => onNavigate("create")}
            className="flex-1 flex items-center justify-center gap-2 text-sm font-bold py-4 rounded-2xl text-white shadow-lg shadow-[#6C63FF]/25 hover:opacity-90 transition-all active:scale-[0.98]"
            style={{ background: "linear-gradient(135deg, #6C63FF, #4f46e5)" }}
          >
            <Plus size={16} />
            New Quiz
          </button>
        </div>
      </div>
    </div>
  );
}

// ─── Shared Auth Layout ───────────────────────────────────────────────────────

function AuthLayout({
  children,
  onNavigate,
}: {
  children: React.ReactNode;
  onNavigate: (s: Screen) => void;
}) {
  return (
    <div
      className="min-h-screen flex"
      style={{ fontFamily: "'Plus Jakarta Sans', sans-serif" }}
    >
      {/* Left decorative panel */}
      <div
        className="hidden lg:flex lg:w-5/12 flex-col justify-between p-12 relative overflow-hidden"
        style={{ background: "linear-gradient(145deg, #6C63FF 0%, #4f46e5 55%, #2563eb 100%)" }}
      >
        {/* Decorative circles */}
        <div className="absolute -top-24 -right-24 w-80 h-80 rounded-full bg-white/5" />
        <div className="absolute -bottom-20 -left-16 w-72 h-72 rounded-full bg-[#4CAF50]/10" />
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-64 h-64 rounded-full bg-white/[0.03] border border-white/10" />
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-40 h-40 rounded-full bg-white/[0.04] border border-white/10" />

        {/* Brand */}
        <button
          onClick={() => onNavigate("landing")}
          className="relative flex items-center gap-3 z-10"
        >
          <div className="w-10 h-10 rounded-xl bg-white/20 backdrop-blur-sm flex items-center justify-center border border-white/25 shadow-lg">
            <Zap size={20} className="text-white" />
          </div>
          <span
            className="text-2xl font-extrabold text-white tracking-tight"
            style={{ fontFamily: "'Nunito', sans-serif" }}
          >
            Quizify
          </span>
        </button>

        {/* Center copy */}
        <div className="relative z-10">
          <div className="flex gap-3 mb-8">
            {[
              { icon: <Zap size={14} />, label: "Create quizzes in minutes" },
              { icon: <Users size={14} />, label: "Play with anyone, anywhere" },
              { icon: <BarChart3 size={14} />, label: "Track every result" },
            ].map((item) => (
              <div
                key={item.label}
                className="flex items-center gap-2 bg-white/10 backdrop-blur-sm text-white/90 text-xs font-semibold px-3 py-2 rounded-xl border border-white/15"
              >
                {item.icon}
                <span className="hidden xl:inline">{item.label}</span>
              </div>
            ))}
          </div>
          <h2
            className="text-4xl font-extrabold text-white leading-tight mb-4"
            style={{ fontFamily: "'Nunito', sans-serif" }}
          >
            Learning that
            <br />
            <span className="text-[#a5f3a5]">feels like play.</span>
          </h2>
          <p className="text-white/65 text-sm leading-relaxed max-w-xs">
            Join 48,000+ learners who use Quizify to create engaging quizzes and compete in real-time.
          </p>
        </div>

        {/* Testimonial */}
        <div className="relative z-10 bg-white/10 backdrop-blur-sm rounded-2xl p-5 border border-white/15">
          <div className="flex gap-1 mb-3">
            {[...Array(5)].map((_, i) => (
              <Star key={i} size={13} className="text-[#FFD700] fill-[#FFD700]" />
            ))}
          </div>
          <p className="text-white/85 text-sm leading-relaxed mb-4">
            "Quizify transformed how my students engage with material. The real-time leaderboard is addictive!"
          </p>
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-[#4CAF50]/30 flex items-center justify-center text-sm font-bold text-white">
              MR
            </div>
            <div>
              <p className="text-white text-xs font-semibold">Maya Rodriguez</p>
              <p className="text-white/50 text-xs">High School Biology Teacher</p>
            </div>
          </div>
        </div>
      </div>

      {/* Right form panel */}
      <div className="flex-1 flex flex-col items-center justify-center px-6 py-16 bg-[#f8f7ff]">
        {children}
      </div>
    </div>
  );
}

// ─── Login ────────────────────────────────────────────────────────────────────

function Login({ onNavigate }: { onNavigate: (s: Screen) => void }) {
  const [showPw, setShowPw] = useState(false);
  const [email, setEmail] = useState("");
  const [pw, setPw] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email || !pw) { setError("Please fill in all fields."); return; }
    setError("");
    setLoading(true);
    setTimeout(() => { setLoading(false); onNavigate("landing"); }, 1200);
  };

  return (
    <AuthLayout onNavigate={onNavigate}>
      <div className="w-full max-w-md">
        {/* Header */}
        <div className="mb-8">
          <h1
            className="text-3xl font-extrabold text-[#1a1535] mb-2"
            style={{ fontFamily: "'Nunito', sans-serif" }}
          >
            Welcome back
          </h1>
          <p className="text-[#6b6a8a] text-sm">
            Sign in to your account to continue.
          </p>
        </div>

        {/* Social buttons */}
        <div className="flex gap-3 mb-6">
          <button className="flex-1 flex items-center justify-center gap-2 py-3 rounded-xl border-2 border-[rgba(108,99,255,0.15)] bg-white text-[#1a1535] text-sm font-semibold hover:border-[#6C63FF]/35 hover:bg-[#fafaff] transition-all">
            <svg width="18" height="18" viewBox="0 0 18 18">
              <path d="M16.51 8H8.98v3h4.3c-.18 1-.74 1.48-1.6 2.04v2.01h2.6a7.8 7.8 0 0 0 2.38-5.88c0-.57-.05-.66-.15-1.18z" fill="#4285F4" />
              <path d="M8.98 17c2.16 0 3.97-.72 5.3-1.94l-2.6-2.01c-.72.48-1.63.76-2.7.76-2.08 0-3.84-1.4-4.47-3.29H1.84v2.07A8 8 0 0 0 8.98 17z" fill="#34A853" />
              <path d="M4.51 10.52A4.84 4.84 0 0 1 4.26 9c0-.53.09-1.04.25-1.52V5.41H1.84A8 8 0 0 0 .98 9c0 1.29.31 2.51.86 3.59l2.67-2.07z" fill="#FBBC05" />
              <path d="M8.98 3.58c1.17 0 2.23.4 3.06 1.2l2.3-2.3A8 8 0 0 0 .98 9l2.66 2.07A4.77 4.77 0 0 1 8.98 3.58z" fill="#EA4335" />
            </svg>
            Google
          </button>
          <button className="flex-1 flex items-center justify-center gap-2 py-3 rounded-xl border-2 border-[rgba(108,99,255,0.15)] bg-white text-[#1a1535] text-sm font-semibold hover:border-[#6C63FF]/35 hover:bg-[#fafaff] transition-all">
            <Github size={18} />
            GitHub
          </button>
        </div>

        {/* Divider */}
        <div className="flex items-center gap-4 mb-6">
          <div className="flex-1 h-px bg-[rgba(108,99,255,0.1)]" />
          <span className="text-xs text-[#6b6a8a] font-medium">or continue with email</span>
          <div className="flex-1 h-px bg-[rgba(108,99,255,0.1)]" />
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="space-y-4">
          {error && (
            <div className="flex items-center gap-2 bg-red-50 border border-red-200 text-red-600 text-xs font-semibold px-4 py-3 rounded-xl">
              <AlertCircle size={14} />
              {error}
            </div>
          )}

          <div>
            <label className="block text-sm font-semibold text-[#1a1535] mb-2">Email address</label>
            <div className="relative">
              <Mail size={15} className="absolute left-4 top-1/2 -translate-y-1/2 text-[#6b6a8a]" />
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="you@example.com"
                className="w-full bg-white border-2 border-[rgba(108,99,255,0.12)] rounded-xl pl-11 pr-4 py-3 text-sm text-[#1a1535] placeholder-[#b4b3cc] focus:outline-none focus:border-[#6C63FF] focus:ring-4 focus:ring-[#6C63FF]/10 transition-all"
              />
            </div>
          </div>

          <div>
            <div className="flex justify-between mb-2">
              <label className="text-sm font-semibold text-[#1a1535]">Password</label>
              <button type="button" className="text-xs font-semibold text-[#6C63FF] hover:underline">
                Forgot password?
              </button>
            </div>
            <div className="relative">
              <Lock size={15} className="absolute left-4 top-1/2 -translate-y-1/2 text-[#6b6a8a]" />
              <input
                type={showPw ? "text" : "password"}
                value={pw}
                onChange={(e) => setPw(e.target.value)}
                placeholder="Enter your password"
                className="w-full bg-white border-2 border-[rgba(108,99,255,0.12)] rounded-xl pl-11 pr-12 py-3 text-sm text-[#1a1535] placeholder-[#b4b3cc] focus:outline-none focus:border-[#6C63FF] focus:ring-4 focus:ring-[#6C63FF]/10 transition-all"
              />
              <button
                type="button"
                onClick={() => setShowPw((v) => !v)}
                className="absolute right-4 top-1/2 -translate-y-1/2 text-[#6b6a8a] hover:text-[#6C63FF] transition-colors"
              >
                {showPw ? <EyeOff size={15} /> : <Eye size={15} />}
              </button>
            </div>
          </div>

          <div className="flex items-center gap-3 pt-1">
            <input
              type="checkbox"
              id="remember"
              className="w-4 h-4 rounded border-[rgba(108,99,255,0.3)] accent-[#6C63FF]"
            />
            <label htmlFor="remember" className="text-sm text-[#6b6a8a] font-medium">
              Remember me for 30 days
            </label>
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full flex items-center justify-center gap-2 py-3.5 rounded-xl text-white font-bold text-sm transition-all shadow-lg shadow-[#6C63FF]/25 hover:opacity-90 active:scale-[0.98] disabled:opacity-70 mt-2"
            style={{ background: "linear-gradient(135deg, #6C63FF, #4f46e5)" }}
          >
            {loading ? (
              <>
                <div className="w-4 h-4 border-2 border-white/40 border-t-white rounded-full animate-spin" />
                Signing in…
              </>
            ) : (
              <>Sign In <ChevronRight size={16} /></>
            )}
          </button>
        </form>

        <p className="text-center text-sm text-[#6b6a8a] mt-6">
          Don&apos;t have an account?{" "}
          <button
            onClick={() => onNavigate("register")}
            className="font-bold text-[#6C63FF] hover:underline"
          >
            Sign up for free
          </button>
        </p>
      </div>
    </AuthLayout>
  );
}

// ─── Register ─────────────────────────────────────────────────────────────────

function Register({ onNavigate }: { onNavigate: (s: Screen) => void }) {
  const [showPw, setShowPw] = useState(false);
  const [name, setName] = useState("");
  const [username, setUsername] = useState("");
  const [email, setEmail] = useState("");
  const [pw, setPw] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const pwStrength = pw.length === 0 ? 0 : pw.length < 6 ? 1 : pw.length < 10 ? 2 : /[A-Z]/.test(pw) && /[0-9]/.test(pw) ? 4 : 3;
  const strengthLabel = ["", "Weak", "Fair", "Good", "Strong"][pwStrength];
  const strengthColor = ["", "#ef4444", "#f59e0b", "#4CAF50", "#6C63FF"][pwStrength];
  const strengthWidth = ["0%", "25%", "50%", "75%", "100%"][pwStrength];

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !email || !pw) { setError("Please fill in all required fields."); return; }
    if (pw.length < 6) { setError("Password must be at least 6 characters."); return; }
    setError("");
    setLoading(true);
    setTimeout(() => { setLoading(false); onNavigate("landing"); }, 1400);
  };

  return (
    <AuthLayout onNavigate={onNavigate}>
      <div className="w-full max-w-md">
        {/* Header */}
        <div className="mb-8">
          <h1
            className="text-3xl font-extrabold text-[#1a1535] mb-2"
            style={{ fontFamily: "'Nunito', sans-serif" }}
          >
            Create your account
          </h1>
          <p className="text-[#6b6a8a] text-sm">
            Free forever. No credit card required.
          </p>
        </div>

        {/* Social buttons */}
        <div className="flex gap-3 mb-6">
          <button className="flex-1 flex items-center justify-center gap-2 py-3 rounded-xl border-2 border-[rgba(108,99,255,0.15)] bg-white text-[#1a1535] text-sm font-semibold hover:border-[#6C63FF]/35 hover:bg-[#fafaff] transition-all">
            <svg width="18" height="18" viewBox="0 0 18 18">
              <path d="M16.51 8H8.98v3h4.3c-.18 1-.74 1.48-1.6 2.04v2.01h2.6a7.8 7.8 0 0 0 2.38-5.88c0-.57-.05-.66-.15-1.18z" fill="#4285F4" />
              <path d="M8.98 17c2.16 0 3.97-.72 5.3-1.94l-2.6-2.01c-.72.48-1.63.76-2.7.76-2.08 0-3.84-1.4-4.47-3.29H1.84v2.07A8 8 0 0 0 8.98 17z" fill="#34A853" />
              <path d="M4.51 10.52A4.84 4.84 0 0 1 4.26 9c0-.53.09-1.04.25-1.52V5.41H1.84A8 8 0 0 0 .98 9c0 1.29.31 2.51.86 3.59l2.67-2.07z" fill="#FBBC05" />
              <path d="M8.98 3.58c1.17 0 2.23.4 3.06 1.2l2.3-2.3A8 8 0 0 0 .98 9l2.66 2.07A4.77 4.77 0 0 1 8.98 3.58z" fill="#EA4335" />
            </svg>
            Google
          </button>
          <button className="flex-1 flex items-center justify-center gap-2 py-3 rounded-xl border-2 border-[rgba(108,99,255,0.15)] bg-white text-[#1a1535] text-sm font-semibold hover:border-[#6C63FF]/35 hover:bg-[#fafaff] transition-all">
            <Github size={18} />
            GitHub
          </button>
        </div>

        {/* Divider */}
        <div className="flex items-center gap-4 mb-6">
          <div className="flex-1 h-px bg-[rgba(108,99,255,0.1)]" />
          <span className="text-xs text-[#6b6a8a] font-medium">or sign up with email</span>
          <div className="flex-1 h-px bg-[rgba(108,99,255,0.1)]" />
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="space-y-4">
          {error && (
            <div className="flex items-center gap-2 bg-red-50 border border-red-200 text-red-600 text-xs font-semibold px-4 py-3 rounded-xl">
              <AlertCircle size={14} />
              {error}
            </div>
          )}

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-sm font-semibold text-[#1a1535] mb-2">Full Name</label>
              <div className="relative">
                <User size={15} className="absolute left-4 top-1/2 -translate-y-1/2 text-[#6b6a8a]" />
                <input
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="Alex Rivera"
                  className="w-full bg-white border-2 border-[rgba(108,99,255,0.12)] rounded-xl pl-10 pr-3 py-3 text-sm text-[#1a1535] placeholder-[#b4b3cc] focus:outline-none focus:border-[#6C63FF] focus:ring-4 focus:ring-[#6C63FF]/10 transition-all"
                />
              </div>
            </div>
            <div>
              <label className="block text-sm font-semibold text-[#1a1535] mb-2">Username</label>
              <div className="relative">
                <AtSign size={15} className="absolute left-4 top-1/2 -translate-y-1/2 text-[#6b6a8a]" />
                <input
                  type="text"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  placeholder="alexr"
                  className="w-full bg-white border-2 border-[rgba(108,99,255,0.12)] rounded-xl pl-10 pr-3 py-3 text-sm text-[#1a1535] placeholder-[#b4b3cc] focus:outline-none focus:border-[#6C63FF] focus:ring-4 focus:ring-[#6C63FF]/10 transition-all"
                />
              </div>
            </div>
          </div>

          <div>
            <label className="block text-sm font-semibold text-[#1a1535] mb-2">Email address</label>
            <div className="relative">
              <Mail size={15} className="absolute left-4 top-1/2 -translate-y-1/2 text-[#6b6a8a]" />
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="you@example.com"
                className="w-full bg-white border-2 border-[rgba(108,99,255,0.12)] rounded-xl pl-11 pr-4 py-3 text-sm text-[#1a1535] placeholder-[#b4b3cc] focus:outline-none focus:border-[#6C63FF] focus:ring-4 focus:ring-[#6C63FF]/10 transition-all"
              />
            </div>
          </div>

          <div>
            <label className="block text-sm font-semibold text-[#1a1535] mb-2">Password</label>
            <div className="relative">
              <Lock size={15} className="absolute left-4 top-1/2 -translate-y-1/2 text-[#6b6a8a]" />
              <input
                type={showPw ? "text" : "password"}
                value={pw}
                onChange={(e) => setPw(e.target.value)}
                placeholder="Create a strong password"
                className="w-full bg-white border-2 border-[rgba(108,99,255,0.12)] rounded-xl pl-11 pr-12 py-3 text-sm text-[#1a1535] placeholder-[#b4b3cc] focus:outline-none focus:border-[#6C63FF] focus:ring-4 focus:ring-[#6C63FF]/10 transition-all"
              />
              <button
                type="button"
                onClick={() => setShowPw((v) => !v)}
                className="absolute right-4 top-1/2 -translate-y-1/2 text-[#6b6a8a] hover:text-[#6C63FF] transition-colors"
              >
                {showPw ? <EyeOff size={15} /> : <Eye size={15} />}
              </button>
            </div>
            {pw.length > 0 && (
              <div className="mt-2">
                <div className="flex justify-between items-center mb-1">
                  <span className="text-xs text-[#6b6a8a]">Password strength</span>
                  <span className="text-xs font-semibold" style={{ color: strengthColor }}>{strengthLabel}</span>
                </div>
                <div className="h-1.5 bg-[#ededf5] rounded-full overflow-hidden">
                  <div
                    className="h-full rounded-full transition-all duration-300"
                    style={{ width: strengthWidth, background: strengthColor }}
                  />
                </div>
              </div>
            )}
          </div>

          {/* Perks row */}
          <div className="flex gap-4 bg-[#f4f3ff] rounded-xl p-3">
            {["Unlimited quizzes", "Live leaderboards", "Analytics"].map((perk) => (
              <div key={perk} className="flex items-center gap-1.5 text-xs font-semibold text-[#6C63FF]">
                <CheckCircle size={12} className="text-[#4CAF50]" />
                {perk}
              </div>
            ))}
          </div>

          <div className="flex items-start gap-3 pt-1">
            <input
              type="checkbox"
              id="terms"
              className="w-4 h-4 mt-0.5 rounded border-[rgba(108,99,255,0.3)] accent-[#6C63FF] shrink-0"
            />
            <label htmlFor="terms" className="text-xs text-[#6b6a8a] leading-relaxed">
              I agree to the{" "}
              <span className="font-semibold text-[#6C63FF] hover:underline cursor-pointer">Terms of Service</span>
              {" "}and{" "}
              <span className="font-semibold text-[#6C63FF] hover:underline cursor-pointer">Privacy Policy</span>
            </label>
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full flex items-center justify-center gap-2 py-3.5 rounded-xl text-white font-bold text-sm transition-all shadow-lg shadow-[#6C63FF]/25 hover:opacity-90 active:scale-[0.98] disabled:opacity-70"
            style={{ background: "linear-gradient(135deg, #6C63FF, #4f46e5)" }}
          >
            {loading ? (
              <>
                <div className="w-4 h-4 border-2 border-white/40 border-t-white rounded-full animate-spin" />
                Creating account…
              </>
            ) : (
              <>Create Free Account <ChevronRight size={16} /></>
            )}
          </button>
        </form>

        <p className="text-center text-sm text-[#6b6a8a] mt-6">
          Already have an account?{" "}
          <button
            onClick={() => onNavigate("login")}
            className="font-bold text-[#6C63FF] hover:underline"
          >
            Sign in
          </button>
        </p>
      </div>
    </AuthLayout>
  );
}

// ─── App Shell ────────────────────────────────────────────────────────────────

export default function App() {
  const [screen, setScreen] = useState<Screen>("landing");

  return (
    <div className="min-h-screen bg-[#f8f7ff]">
      {screen !== "login" && screen !== "register" && <Nav onNavigate={setScreen} />}
      {screen === "landing" && <Landing onNavigate={setScreen} />}
      {screen === "login" && <Login onNavigate={setScreen} />}
      {screen === "register" && <Register onNavigate={setScreen} />}
      {screen === "create" && <QuizCreator onNavigate={setScreen} />}
      {screen === "quiz" && <QuizScreen onNavigate={setScreen} />}
      {screen === "leaderboard" && <Leaderboard onNavigate={setScreen} />}
    </div>
  );
}
