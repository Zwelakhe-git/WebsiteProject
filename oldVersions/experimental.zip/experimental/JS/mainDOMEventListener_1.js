//import indexPageLoader from '/JS/indexPageLoader.js'
import scriptIndx from './scriptIndx.js'
import newsFadeAnimation from '/JS/newsFadeAnimation.js'
import rpVidScript from '/JS/rpVidScript.js'
import slidesScript from '/JS/slidesScript.js'
import eventsFadeAnimation from '/JS/eventsFadeAnimation.js'
import searchPg from '/JS/searchPg.js'
import mediaStat from '/JS/mediaStat.js'

//indexPageLoader();
slidesScript();
scriptIndx();
newsFadeAnimation();
eventsFadeAnimation();
rpVidScript();
mediaStat();
//searchPg();