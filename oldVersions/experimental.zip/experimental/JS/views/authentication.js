import updateProfileUI from '/account/profile.js';

function signForm(formtype = 'login'){
    return `<form class='regForm'>
        <div class='form-close'>
            <i class="fa-solid fa-xmark close-icon"></i>
        </div>
        <div class='field'>
            <label for='login'>Login<span class='required-mark'>*</span></label>
            <input id='login' type='text' name='login' placeholder='username or login'/>
        </div>
        <div class='field'>
            <label for='email'>email<span class='required-mark'>*</span></label>
            <input id='email' type='email' name='email'/>
        </div>
        <div class='field'>
            <label for='password'>password<span class='required-mark'>*</span></label>
            <input id='password' type='password' name='password' placeholder='password'/>
            <div class='field row'>
                <label>Show password</label>
                <input id='show-pswd' type='checkbox' name='show-pswd'/>
            </div>
        </div>
        <div class='form-btns'>
            <button id='send-btn' type='button'></button>
        </div>
        <div id="google-login-container"></div>
        <p id='form-btm-text'></p>
       </form>
        `;
}

function createGoogleLoginButton() {
    return `
        <div class="divider">
            <span>Or continue with</span>
        </div>
        <button type="button" id="google-login-btn" class="google-login-btn">
            <i class="fa-brands fa-google google-icon"></i>
            <span>Continue with Google</span>
        </button>
    `;
}

export function renderForm(formtype, closeOnLog = true){
    if(document.querySelector('.form-container')){
        return;
    }
    let formContainer = document.createElement('div');
    formContainer.classList.add('form-container');
    formContainer.innerHTML = signForm(formtype);
    document.body.appendChild(formContainer);
    
    let form = formContainer.querySelector('.regForm');
    renderFormUI();
    form.style.display = 'block';
    let timer1 = null;
    let timer2 = null;

    timer1 = setTimeout(()=>{
      form.classList.add('open');
      let pswdField = form.querySelector('#password');
      let loginField = form.querySelector('#login');
      let closeIcon = form.querySelector('.close-icon');
      let sendBtn = form.querySelector('#send-btn');
      let googleLoginContainer = form.querySelector('#google-login-container');
        
      // Add Google login button to the form
      googleLoginContainer.innerHTML = createGoogleLoginButton();
        
      loginField.addEventListener('input', (event) => {
          loginField.value = loginField.value.replace(/[^A-Za-z0-9]/g, '');
      });
        
      if(closeOnLog){
          closeIcon.addEventListener('click', ()=>{
            form.classList.remove('open');
            timer2 = setTimeout(()=>{
              formContainer.style.display = 'none';
              document.body.removeChild(formContainer);
            }, 500);
          });
      }
      
      // Google login button event listener
      let googleLoginBtn = form.querySelector('#google-login-btn');
      googleLoginBtn.addEventListener('click', async () => {
          googleLoginBtn.disabled = true;
          googleLoginBtn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i><span>Loading...</span>';
          
          try {
              let response = await fetch('/php/dbReader.php?q=googleAuthUrl');
              let data = await response.json();
              
              if (data.auth_url) {
                  window.location.href = data.auth_url;
              } else if (data.error) {
                  throw new Error(data.error);
              } else {
                  throw new Error('No authentication URL received from server');
              }
          } catch (error) {
              console.error('Google login error:', error);
              let errorMessage = 'Google authentication is not available at the moment.';
              
              if (error.message.includes('not configured') || error.message.includes('configuration missing')) {
                  errorMessage = 'Google authentication is not configured. Please contact administrator.';
              } else if (error.message.includes('config file missing')) {
                  errorMessage = 'Google authentication setup incomplete. Please contact administrator.';
              }
              
              showAlert(errorMessage, 'error', formContainer);
              
              // Reset button
              googleLoginBtn.disabled = false;
              googleLoginBtn.innerHTML = '<i class="fa-brands fa-google google-icon"></i><span>Continue with Google</span>';
          }
      });
      
      sendBtn.addEventListener('click', async (e)=>{
          try{
              let formData = new FormData(form);
              for(const [key, value] of  formData.entries()){
                  if(value.trim().length === 0){
                      showAlert('Please fill in all required fields', 'error', formContainer);
                      return;
                  }
              }
              const params = new URLSearchParams(formData);

              let response = (formtype === 'login') ? await fetch('/php/dbReader.php?r=userlogin', {
                  method: 'POST',
                  headers: {
                      'Content-Type': 'application/x-www-form-urlencoded'
                  },
                  body: params.toString()
              }) : await fetch('/php/dbReader.php?r=userRegister', {
                  method: 'POST',
                  headers: {
                      'Content-Type': 'application/x-www-form-urlencoded'
                  },
                  body: params.toString()
              });
              let data = await response.json();
              console.log(data);
              
              if(data.response === 'success'){
                  showAlert('Success! Redirecting...', 'success', formContainer);
                  window.currentUser = formtype === 'login' ? data.message : 'guest';
                  updateProfileUI();
                  
                  if(closeOnLog){
                      setTimeout(()=>{
                          closeIcon.click();
                      }, 1000);
                  }
                  
              } else if(data.response === 'fail'){
                  showAlert(data.message, 'error', formContainer);
              }
              
          } catch(error){
              console.log(error.message);
              showAlert('An error occurred. Please try again.', 'error', formContainer);
          }
      });

      let showPswdCheckBx = form.querySelector('#show-pswd');
      showPswdCheckBx.addEventListener('change', (e)=>{
        pswdField.type = e.currentTarget.checked ? 'text' : 'password';
      });
    }, 500);
    
    function renderFormUI(){
        let sendBtn = form.querySelector('#send-btn');
        let formBtmParag = form.querySelector('#form-btm-text');
        
        sendBtn.textContent = formtype === 'login' ? 'Log in' : 'Sign up';
        formBtmParag.innerHTML = formtype === 'login' ? "Don't have an account yet? <a id='sign-link'>Sign Up</a>" : "Already have an account? <a id='reg-link'>Log in</a>";
        
        let formLink = form.querySelector('a');
        formLink.addEventListener('click', ()=>{
            formtype = formtype === 'login' ? 'register' : 'login';
            renderFormUI();
        });
    }
}

function showAlert(message, type, container) {
    // Remove existing alerts
    const existingAlerts = container.querySelectorAll('.alert');
    existingAlerts.forEach(alert => alert.remove());
    
    const alertDiv = document.createElement('div');
    alertDiv.className = `alert alert-${type === 'success' ? 'ok' : 'err'}`;
    alertDiv.innerHTML = `
        <i class="fa-solid ${type === 'success' ? 'fa-circle-check' : 'fa-circle-exclamation'}"></i>
        <span>${message}</span>
    `;
    
    container.appendChild(alertDiv);
    
    setTimeout(() => {
        if (alertDiv.parentNode) {
            alertDiv.remove();
        }
    }, 5000);
}

function pageInnerStyle(){
    return `
@media (min-width: 480px){
    .regForm{
        width: 300px;
        top: 15%;
    }
}

@media (max-width: 480px){
    .regForm{
        width: 95%;
        top: 25%;
    }
}

.form-container{
position: fixed;
z-index: 5;
width: 100%;
height: 100%;
top: 0;
background-color: #f5f5f591;
}
.regForm{
  box-sizing: border-box;
	position: relative;
    border-radius: 8px;
	padding: 10px;
    transform: scale(0);
    margin: auto;
    display: none;
    transition: transform 0.5s ease-in-out;
    box-shadow: 0px 0px 5px grey;
    background-color: white;
}
.regForm.open{
	transform: scale(1);
}
.regForm a{
  color: red;
  text-decoration: underline;
  cursor: pointer;
}

.regForm > div{
	margin-bottom: 10px;
}
.field, .form-btns{
	display: flex;
    flex-direction: column;
    gap: 5px;
}

.field.row{
	flex-direction: row;
    align-items: center;
    gap: 10px;
}
input:not([type='checkbox']){
  border: none;
  border-bottom: 1px solid black;
  padding: 5px;
  font-size: 16px;
}
input:focus{
  outline: none;
}
#send-btn{
	padding: 12px;
  border-radius: 8px;
    border: none;
    background-color: #0f2c4f;
    color: white;
    font-weight: 600;
    cursor: pointer;
    font-size: 16px;
}
#send-btn:hover {
    background-color: #1a3d6d;
}

/* Google Login Styles */
.google-login-container {
    margin: 20px 0;
}

.divider {
    display: flex;
    align-items: center;
    margin: 20px 0;
    color: #666;
    font-size: 14px;
}

.divider::before,
.divider::after {
    content: '';
    flex: 1;
    border-bottom: 1px solid #ddd;
}

.divider span {
    padding: 0 10px;
}

.google-login-btn {
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 10px;
    width: 100%;
    padding: 12px;
    border: 1px solid #ddd;
    border-radius: 8px;
    background: white;
    color: #333;
    font-size: 16px;
    cursor: pointer;
    transition: all 0.3s ease;
    margin-bottom: 15px;
}

.google-login-btn:hover:not(:disabled) {
    background: #f5f5f5;
    border-color: #ccc;
    transform: translateY(-1px);
    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
}

.google-login-btn:disabled {
    opacity: 0.6;
    cursor: not-allowed;
}

.google-icon {
    color: #4285F4;
    font-size: 16px;
}

.fa-spin {
    animation: fa-spin 1s infinite linear;
}

@keyframes fa-spin {
    0% { transform: rotate(0deg); }
    100% { transform: rotate(360deg); }
}

.alert {
    width: 90%;
    margin: 10px auto;
    text-align: center;
    font-weight: 600;
    padding: 12px;
    border-radius: 8px;
    font-size: 14px;
}
.alert.alert-ok {
    color: green;
    background-color: #90ee90cf;
    border: 1px solid #90ee90;
}
.alert.alert-err {
    color: red;
    background-color: #ee9090cf;
    border: 1px solid #ee9090;
}`;
}
    
function userAuthPage(resourcesLoaded){
    let styleTag = document.querySelector('#root-style');
    if(!resourcesLoaded){
        styleTag.innerHTML += pageInnerStyle();
    }
    var formtype = 'register';
    renderForm(formtype);
}
export default userAuthPage;