import slideContainer from '/JS/bottomscroll.js';

const MAX_NEWS_SLIDES = 10;
function head(newsData){
    let slides = ``;
  for( let i = 0; i <= MAX_NEWS_SLIDES && i < newsData.length; ++i){
      slides += `<div class="slide-image-container full-w-h" data-id="${newsData[i].id}">
        <img alt="news image"  src="${newsData[i].image_location}" class="slide-image cvr full-w" />
        <p class="slide-img-desc">${newsData[i].newsTitle}</p>
      </div>`;
  }
  return `
  <div id="head">
    <div id="news-slides">
      ${slides}
    </div>
    <div class="scroll-btn right">
      <ion-icon name='arrow-forward-outline' class='icon'></ion-icon>
    </div>
    <div class="scroll-btn left">
      <ion-icon name='arrow-back-outline' class='icon'></ion-icon>
    </div>
    <a href="/?p=actuality" id="slide-link" class="link no-dec">
        <span>Wè Plis</span>
        <i class="fa-solid fa-chevron-right"></i>
      </a>
  </div>
  `;
}

function lastNews(newsData){
  const MAX_NEWS_FADE_CONTENT = 20;
  let newsList = '';
  for(let index = 0; index <= MAX_NEWS_FADE_CONTENT && index < newsData.length; ++index){
      newsList += `
    <article class="full-w artcl-itm flxDisp">
        <div class="news-content full-w flxDisp">
            <a href="" class="news-content-link flxDisp">
                <img class="news-img" src="${newsData[index].image_location}" alt="news cover image">
            </a>
            <div class="news-headline flxDisp no-margin">
                <h1 class="no-margin">${newsData[index].newsTitle}</h1>
                <p class="news-a">${newsData[index].newsContent}</p>
                <div class="flxDisp artc-info">
                <ion-icon class="news-tm" name="time-outline"></ion-icon>
                <span class="date">${newsData[index].newsDate}</span>
                </div>
            </div>
        </div>
    </article>
    `;
  }
  return `
  <div id="last-news" class="margin-rl-1">
    <div class="section-info">
      <a href="/?p=actuality">
      	<h1>DENYÈ NOUVEL</h1>
      </a>
    </div>
    <div class="articles">
    	${newsList}
    </div>
    <a href="/?p=actuality">
      <div class="more-actions">
        <span>Wè Plis</span>
        <ion-icon name="arrow-forward-outline"></ion-icon>
      </div>
    </a>
  </div>`;
}

function eventsSection(eventsData){
  let eventsList = '';
  for(let index = 0; index < eventsData.length; ++index){
      eventsList += `<div class="event-card">
    <div class="ev-container">
        <img src="${eventsData[index].image_location}" alt="${eventsData[index].title}" class="event-image" />
        <div class="event-content">
            <div class="ticket-info">
                <span>Ticket Price</span>
                <span class="ticket-price">\$${eventsData[index].price}</span>
            </div>
            <a href="/?f=event&id=${eventsData[index].id}" class="buy-btn">Buy Ticket</a>
        </div>
    </div>
</div>`;
  }
  return `
  <div id="events-section" class="margin-rl-1 colDir">
          <div id="events-section-bg" class="full-h"></div>
          <div class="section-info">
            <a href="/?p=events"><h1>EVENEMAN</h1></a>
          </div>
          <div id="events-list">
          	${eventsList}
          </div>
          <a href="/?p=events">
            <div class="more-actions">
              <span>Wè Plis</span>
              <ion-icon name="arrow-forward-outline"></ion-icon>
          </div>
          </a>
        </div>`;
}

function middlePanel(content){
    const MAX_MUSIC_CONTENT = 5;
    let count = 0;
    let tracksList = '';
    for(let index = 0; index < content.length; ++index){
        if(count >= MAX_MUSIC_CONTENT){
            break;
        }
        let formattedName = content[index].track_name.replaceAll(" ","_");
        tracksList += `<div class="track"
        id="track-${content[index].id}"
        ${content[index].location.length > 0 && `data-src="${content[index].location}"`  }
        data-trackid="${content[index].id}">
            <div class="track-img">
                <img class="full-w-h" alt="track image" src="${content[index].image_location}" />
            </div>
            <div class="music-info">
                <div class="music-title">${content[index].track_name}</div>
                <div class="music-artist">${content[index].artist_name}</div>
                <div class="player-controls">
                    <div class="play-btn" data-trackid="${content[index].id}">
                        <i class="fas fa-play media-ico play"
                        data-trackid="${content[index].id}"
                        ${content[index].location.length > 0 && `data-src="${content[index].location}"`  }
                        data-tracktitle=${formattedName}></i>
                    </div>
                    <div class="progress-bar">
                        <div class="progress track-${content[index].id}"></div>
                    </div>
                    <div class="music-duration track-${content[index].id}"></div>
                </div>
                <div class="media-actions">
                    <div class="action-btn download-btn">
                        <i class="fas fa-download media-ico" data-trackid="${content[index].id}" data-tracktitle="${formattedName}"></i>
                        <span>${content[index].downloads}</span>
                    </div>
                    <div class="action-btn like-btn">
                        <i class="fa-regular fa-heart media-ico" data-trackid="${content[index].id}" data-tracktitle="${formattedName}"></i>
                        <span>${content[index].likes}</span>
                    </div>
                    <div class="action-btn plays-btn">
                        <ion-icon name="eye-outline" class="media-ico" data-trackid="${content[index].id}" data-tracktitle=${formattedName}></ion-icon>
                        <span>${content[index].plays}</span>
                    </div>
                </div>
            </div>                                            
        </div>`  
        ++count;
    }
  return `
  <div id="middle-panel" class="margin-rl-1 colDir">
          <div class="section-info">
              <a href="/?p=music">
                <h1>
                  PLEYLIS
                </h1>
              </a>
            </div>
          <div id="music-charts-video" class="flxDisp colDir">
            <!-- new update: combine charts and videos -->
            
            <div class="media-row-content charts">
              <!-- this space should be automatically filled in JS -->
               <div class="section-info charts-title">
                <h2>TOP CHARTS</h2>
               </div>
              <div class="audio-charts flxDisp">
              	${tracksList}
              </div>
              <a href="/?p=music">
              <div class="more-actions">
                <span>Wè Plis</span>
                <ion-icon name="arrow-forward-outline"></ion-icon>
              </div>
              </a>
            </div>
          </div>
          <audio id="audio-player"></audio>
        </div>
        `;
}

function rightPanel(){
  return `
  <div id="right-panel" class="margin-rl-1">
          <div id="essentials-section">
            <div class="section-info">
              <a href="/?p=actuality"><h1>VIDEYO</h1></a>
            </div>
            <div id="link-portrait-video">
                <div class="vid-container">
                    <div id="rp-vid-container" class="html5-vid"></div>
                </div>
            </div>
          </div>
        </div>`;
}

function servicesPanel(servicesData){
  let servicesList = '';
  for(let index = 0; index < servicesData.length; ++index){
      servicesList += `<div class="serv-container">
        <div class="service-desc">
            <span>${servicesData[index].name}</span>
        </div>
        <div class="service-img">
            <div class="service-img-cont">
                <img alt="service-img" src="${servicesData[index].image_location}"/>
            </div>
        </div>
    </div>`;
  }
  return `
  <div id="services-panel" class="margin-rl-1">
          <div class="section-info">
            <a href="/?p=services"><h1>SEVIS</h1></a>
          </div>
          <!-- preparing containers for pasting -->
          <div class='services-container'>
          	<div id="services-list">
                ${servicesList}
              </div>
              <button class='svc-scroll-btn left' type='button'>
                    <i class="fa-solid fa-chevron-left"></i>
                </button>
                <button class='svc-scroll-btn right' type='button'>
                    <i class="fa-solid fa-chevron-right"></i>
                </button>
          </div>
          <a href="/?p=services">
          <div class="more-actions">
            <span>Wè Plis</span>
            <ion-icon name="arrow-forward-outline"></ion-icon>
          </div>
          </a>
        </div>`;
}

function partnersPanel(partnersData){
      let imgUrls = [
        {
          mime_type : "image/jpeg",
          src : "/media/images/bottom/IMG_4657.JPG.jpg"
        },
        {
          mime_type : "image/jpeg",
          src : "/media/images/bottom/IMG_4658.JPG.jpg"
        },
        {
          mime_type : "image/jpeg",
          src : "/media/images/bottom/IMG_4659.JPG.jpg"
        },
        {
          mime_type : "image/jpeg",
          src : "/media/images/bottom/IMG_4656.JPG.jpg"
        },
        {
          mime_type : "image/jpeg",
          src : "/media/images/bottom/IMG_4660.JPG.jpg"
        },
        {
          mime_type : "image/jpeg",
          src : "/media/images/bottom/IMG_4661.JPG.jpg"
        },
        {
          mime_type : "image/jpeg",
          src : "/media/images/bottom/IMG_4662.JPG.jpg"
        },
          {
          mime_type : "image/jpeg",
          src : "/media/images/bottom/IMG_4664.JPG.jpg"
        },
          {
          mime_type : "image/jpeg",
          src : "/media/images/bottom/IMG_4665.JPG.jpg"
        },
          {
          mime_type : "image/jpeg",
          src : "/media/images/bottom/IMG_5227.JPG.jpg"
        },
       {
          mime_type : "image/jpeg",
          src : "/media/images/bottom/IMG_5244.JPG.jpg"
        },
       {
          mime_type : "image/jpeg",
          src : "/media/images/bottom/IMG_5245.JPG.jpg"
        },

      ]
      let slides = "";
      imgUrls.forEach(imgObj => {
        slides += `
        <div class="slide-container">
          <img type="${imgObj.mime_type}" src="${imgObj.src}"/>
        </div>`;

      });

        setTimeout(() => {
            slideContainer()
        }, 350);
    let partnersList = '';
    partnersData.forEach(partner => {
        partnersList += `<img src="${partner.image_location}"/>`;
    })
  return `
<div id="partners-panel" class="margin-rl-1">
  <div class="section-info">
    <h1>
      PATNE
    </h1>
  </div>
  <div id="partners-list" class="partners">
  	${partnersList}
  </div>
</div>
<div class="bottom-slide">${slides}</div>`;
}

function cookieForm(){
    return `
  <div class='cookie-form-contnent'>
    <div class='cookie-msg'>
      Nou pran angajman pou nou respekte vi prive w avèk pèmisyon w, nou itilize COOKIES ak lòt trasè ankò nan lide pou kontwole odyans nou yo, pataje sou rezo sosyal yo, pèsonalize kontni yo ak piblisite pèsonalize sou sèvis nou yo.
      <a class='wht-clr' href='https://www.konektem.net/privacyandlegalinfo'>Politique de confidentialité</a>
    </div>
    <div class='btns'>
      <button type='button' class='wht-bg' id='cookie-allow'>Accept</button>
      <button type='button' class='transp' id='cookie-deny'>Reject</button>
    </div>
  </div>
`;
}

function pageInnerStyle(){
    return `.cookie-form{
  position: fixed;
  margin: auto;
  max-height: fit-content;
  background-color: #05152e;
  color: white;
  transition: max-height 0.5s ease-in-out, transform 0.5s ease-in-out;
  text-align: center;
  bottom: 0%;
  overflow: hidden;
  z-index: 10;
  box-sizing: border-box;
}
.cookie-form-contnent{
  padding: 10px;
}
.wht-clr{
  color: white;
}

.cookie-form .btns{
  display: flex;
  flex-direction: column;
  padding: 5px;
  gap: 10px;
  margin-top: 10px;
}
.cookie-form.close{
  transform: scale(0);
}


.cookie-form .btns button{
  color: white;
  height: 2rem;
}
.cookie-form .wht-bg{
  background-color: white;
  color: #05152e !important;
}
.transp{
  background-color: transparent;
}
.svc-scroll-btn{
  width: 45px;
  height: 100%;
  position: absolute;
  top: 0;
  opacity: 0.5;
  border: none;
}
.svc-scroll-btn.left{
  left: 0px;
}
.svc-scroll-btn.right{
  right: 0px;
}
`;
}

function cookieClickHandler(){
    let form = document.querySelector('.cookie-form');
    if(form){
        let btns = form.querySelectorAll('button');
        if(btns.length > 0){
            btns.forEach( btn => {
                btn.addEventListener('click', () => {
                    form.classList.add('close');
                    setTimeout(() => {
                        document.body.removeChild(form);
                    },500);
                });
            })
        }
    }
}

function slideAnimation(){
  let slideContainer = document.querySelector('#services-list');
  let leftScrollBtn = document.querySelector('.svc-scroll-btn.left')
  let rightScrollBtn = document.querySelector('.svc-scroll-btn.right')
  var direction = 'right';
  let resumeTO = null;
  let scrollDelay = 3000;
  let numScrolls = 4;
    
  if(!slideContainer){
    console.log('container not found');
    return;
  }
  let scrollEdge = slideContainer.scrollWidth - slideContainer.clientWidth;
  let scrollStep = scrollEdge / numScrolls;

  rightScrollBtn.addEventListener('click', ()=>{
    let initDirection = direction;
    direction = 'right';
    BtnScrollHandler(initDirection);
  });
  leftScrollBtn.addEventListener('click', ()=>{
    let initDirection = direction;
    direction = 'left';
    BtnScrollHandler(initDirection);
  });

  let scrollInterval = setInterval( run, scrollDelay);

  function run(){
    if(slideContainer.scrollLeft === scrollEdge) direction = 'left';
    else if(slideContainer.scrollLeft === 0) direction = 'right';
    
    if(direction === 'right') slideContainer.scrollLeft += scrollStep;
    else if(direction === 'left') slideContainer.scrollLeft -= scrollStep;
  }

  function BtnScrollHandler(initDirection){
    clearInterval(scrollInterval);
    clearTimeout(resumeTO);
    slideContainer.scrollLeft += direction === 'right' ? scrollStep : -scrollStep;

    resumeTO = setTimeout(()=>{
      direction = initDirection;
      scrollInterval = setInterval(run, scrollDelay);
    }, 1000);
  }
}

let styles = ["/experimental/CSS/mobileStyle.css",
  "/experimental/CSS/globalStyle.css",
  "/experimental/CSS/sectionsStyle.css",
  "/experimental/CSS/desktop.css",
  "/CSS/bottomScrollstyle.css"]

let scripts = [
  {
    type : "module",
    src : "/experimental/JS/mainDOMEventListener_1.js"
  }
]

export default function Index(resourcesLoaded){
  let title = document.querySelector("title");
  if(!title){
      title = document.createElemnt("title");
      document.head.insertAdjacentElement("afterbegin", title);
  }
  title.textContent = "Konetkem";
  let root = document.querySelector("#root");
  let rootStyleTag = document.querySelector('#root-style');

  if( !resourcesLoaded ){
      for(const src of styles){
        let linkTag = document.createElement("link");
        linkTag.rel = "stylesheet";
        linkTag.type = "text/css";
        linkTag.href = src;
        document.head.appendChild(linkTag);
      }

      for( const script of scripts ){
        let scriptTag = document.createElement("script");
        scriptTag.type = script.type;
        scriptTag.src = script.src;
        document.head.appendChild(scriptTag);
      }
      if(rootStyleTag){
          rootStyleTag.innerHTML += pageInnerStyle();
      }
  }
  

  if(!root){
    console.log("Index: content container not found");
    return;
  }
  setTimeout( async () => {
      let response = await fetch('/php/dbReader.php?r=news');
      let newsData = await response.json();
      response = await fetch('/php/dbReader.php?r=musicContent');
      let musicData = await response.json();
      response = await fetch('/php/dbReader.php?r=services');
      let servicesData = await response.json();
      response = await fetch('/php/dbReader.php?r=events');
      let eventsData = await response.json();
      response = await fetch('/php/dbReader.php?r=partners');
      let partnersData = await response.json();
      
      let content = ( head(newsData) + lastNews(newsData) + 
                         middlePanel(musicData) + eventsSection(eventsData) + rightPanel() +
                         servicesPanel(servicesData) + partnersPanel(partnersData));
      root.innerHTML = content;
      setTimeout( () => {;
          let div = document.createElement('div');
          div.classList.add('cookie-form');
          div.innerHTML += cookieForm();
          root.parentElement.appendChild(div);
          cookieClickHandler();
          slideAnimation();
      }, 1000)
  }, 200);
}