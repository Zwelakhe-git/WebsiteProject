import Index from './views/index.js';
import actuality from './views/actualityPage.js';
import musicAndVids from './views/musicPage.js';
import streaming from './views/streamingPage.js';
import emailSubPage from './views/emailSubPage.js';
import servicesPage from './views/services.js'; 
import eventsPage from './views/events.js';
import {profLinkClickHandle} from '/account/profile.js';


function setTopBar(){
    let optsIcon = document.querySelector(".opts-icon");
    if(!optsIcon){
        console.log("Options icon not found");
        return;
    }

    optsIcon.addEventListener("click", event => {
      const navPanel = document.querySelector("#nav-panel");
        if( !navPanel ){
            console.log("nav-panel not found");
            return;
        }

        navPanel.classList.toggle("open");
        if(navPanel.classList.contains("open")){
            navPanel.style.display = "block";
            navPanel.style.maxHeight = `${navPanel.scrollHeight}px`;
        }
        else{
            navPanel.style.maxHeight = "0px";
            setTimeout(() => {
                navPanel.style.display = "none";
            }, 350);
        }
    });
    
    return;
}

function footer(){
  let footerEl = document.createElement("footer");
  footerEl.id = "footer";
  footerEl.innerHTML = `
  <footer id="footer">
        <div class="container">
            <div class="footer-content">
                <div class="footer-section">
                    <h3>Konsenan KonektemNews</h3>
                    <p>N ap bay nouvèl ki egzak ak alè soti toupatou nan mond lan. Misyon nou se enfòme, edike, epi angaje lektè nou yo.</p>
                </div>
                <div class="footer-section">
                    <h3>Kategori</h3>
                    <ul>
                        <li><a href="#">Politik</a></li>
                        <li><a href="#">Biznis</a></li>
                        <li><a href="#">Teknoloji</a></li>
                        <li><a href="#">Spo</a></li>
                        <li><a href="#">Divetisman</a></li>
                    </ul>
                </div>
                <div class="footer-section">
                    <h3>Konekte m</h3>
                    <div class="social-icons">
                        <a href="https://www.facebook.com/Konektempageofficielle?mibextid=LQQJ4d"><i class="fab fa-facebook"></i></a>
                        <a href="https://x.com/konektemtv?s=21"><i class="fab fa-twitter"></i></a>
                        <a href="https://www.instagram.com/konektem?igsh=MTBsdWQ0dXl4ZXY5Mg=="><i class="fab fa-instagram"></i></a>
                    </div>
                </div>
                <div class="footer-section">
                    <h3>Abòne ak Bilten Nouvel la</h3>
                    <p>Rete enfòme ak dènye nouvèl ak istwa nou yo lè ou abòne ak bilten enfòmasyon nou an.</p>
                    <form>
                        <input type="email" placeholder="konektemtv@gmail.com" style="padding:10px; width:100%; margin-top:10px; border-radius:4px; border:none;">
                        <button type="submit" style="background:#ffcc00; color:#1a4b8c; border:none; padding:10px 15px; margin-top:10px; border-radius:4px; font-weight:bold; cursor:pointer;">Abone</button>
                    </form>
                </div>
            </div>
            <div class="copyright">
                <p>&copy; 2025 KonektemNews. All rights reserved.</p>
            </div>
        </div>
    </footer>`;

    document.body.insertAdjacentElement("beforeend", footerEl);
}

// global variables
let innerW = window.innerWidth;
let currentDisplay = innerW <= 768 ? "mobile" : "desktop";
let indexContentLoaded = false;
let profileLinkHandleSet = false;

var searchPrams = new URLSearchParams(window.location.search);
let availablePages =
{
    "actuality" : actuality,
    
    "music": musicAndVids,
    
    "streaming" : streaming,
    "emailsubscribtion" : emailSubPage,
    "payments" : function (){
        try{
            window.location.href = `https://zvelakeblog.page.gd/paymentApplication/?f=${searchPrams.get('f')}`;
        } catch(error) {
            console.log("failed to redirect to payment page: ", error);
        }
    },
    "services": servicesPage,
    "events": eventsPage
}


document.addEventListener("DOMContentLoaded", () => {
    setTopBar();
    profLinkClickHandle(profileLinkHandleSet);
    profileLinkHandleSet = true;
    if(searchPrams.get("p")){
        try{
            availablePages[searchPrams.get("p")]();
        } catch(error){
            console.log("invalid page name: " + error);
        }
        
    } else {
        Index(indexContentLoaded);
        indexContentLoaded = true;
    }
    footer();
})
