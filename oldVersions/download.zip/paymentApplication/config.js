
let config = {
    key: "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"
}

export default config;