<?php
error_reporting(0);
// payment-handler.php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type');

require_once 'stripe-php/init.php'; // Скачайте Stripe PHP library
require_once 'config.php';

// Конфигурация
$stripe_secret_key = SK_LIVE;
$paypal_client_id = 'ATDZGyNpLtB6ZRo4FRQ1w9YrNq7CmQh1QayQfwZIWnPM7lhaWqWQRl9tN6rLoRKyYdIsmxEZ5tfUj8uY';
$paypal_secret = 'EE-GXgWZG3gGXbvn-QqQaT8KHueSOhpB_-0gICYJlS2k7TBeUXyoluaRsf8c-Fe-SL6bYyQnHaU92ikv';
$moncash_client_id = 'YOUR_MONCASH_CLIENT_ID';
$moncash_secret = 'YOUR_MONCASH_SECRET';

// Инициализация Stripe
\Stripe\Stripe::setApiKey($stripe_secret_key);

// Получение данных запроса
$input = json_decode(file_get_contents('php://input'), true);
$action = $_POST['action'] ?? $input['action'] ?? '';

try {
    switch ($action) {
        case 'create_payment_intent':
            handleStripePaymentIntent($input);
            break;
        case 'paypal_create_order':
            handlePayPalCreateOrder($input);
            break;
        case 'paypal_capture_order':
            handlePayPalCaptureOrder($input);
            break;
        case 'moncash_create_payment':
            handleMonCashPayment($input);
            break;
        default:
            throw new Exception('Unknown action');
    }
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['error' => $e->getMessage()]);
}

// =============== STRIPE ===============
function handleStripePaymentIntent($data) {
    $amount = intval($data['amount']);
    $currency = $data['currency'] ?? 'usd';
    $email = $data['email'] ?? '';

    $paymentIntent = \Stripe\PaymentIntent::create([
        'amount' => $amount,
        'currency' => $currency,
        'receipt_email' => $email,
        'automatic_payment_methods' => ['enabled' => true],
    ]);

    // changes to response. it was only the clientSecret key
    echo json_encode([
            'success' => true,
            'clientSecret' => $paymentIntent->client_secret,
            'paymentIntentId' => $paymentIntent->id
        ]);
}

// =============== PAYPAL ===============
function handlePayPalCreateOrder($data) {
    global $paypal_client_id, $paypal_secret;
    
    $amount = $data['amount'] ?? '1.80';
    $currency = $data['currency'] ?? 'USD';
    
    $access_token = getPayPalAccessToken($paypal_client_id, $paypal_secret);
    
    $ch = curl_init();
    curl_setopt_array($ch, [
        CURLOPT_URL => 'https://api.sandbox.paypal.com/v2/checkout/orders',
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST => true,
        CURLOPT_HTTPHEADER => [
            'Authorization: Bearer ' . $access_token,
            'Content-Type: application/json',
        ],
        CURLOPT_POSTFIELDS => json_encode([
            'intent' => 'CAPTURE',
            'purchase_units' => [[
                'amount' => [
                    'currency_code' => $currency,
                    'value' => $amount
                ]
            ]]
        ])
    ]);
    
    $response = curl_exec($ch);
    curl_close($ch);
    
    $order_data = json_decode($response, true);
    
    if (isset($order_data['id'])) {
        echo json_encode(['id' => $order_data['id']]);
    } else {
        throw new Exception('PayPal order creation failed');
    }
}

function handlePayPalCaptureOrder($data) {
    global $paypal_client_id, $paypal_secret;
    
    $orderID = $data['orderID'] ?? '';
    $access_token = getPayPalAccessToken($paypal_client_id, $paypal_secret);
    
    $ch = curl_init();
    curl_setopt_array($ch, [
        CURLOPT_URL => "https://api.sandbox.paypal.com/v2/checkout/orders/{$orderID}/capture",
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST => true,
        CURLOPT_HTTPHEADER => [
            'Authorization: Bearer ' . $access_token,
            'Content-Type: application/json',
        ]
    ]);
    
    $response = curl_exec($ch);
    curl_close($ch);
    
    echo $response;
}

function getPayPalAccessToken($client_id, $secret) {
    $ch = curl_init();
    curl_setopt_array($ch, [
        CURLOPT_URL => 'https://api.sandbox.paypal.com/v1/oauth2/token',
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST => true,
        CURLOPT_HTTPHEADER => [
            'Authorization: Basic ' . base64_encode("{$client_id}:{$secret}"),
            'Content-Type: application/x-www-form-urlencoded',
        ],
        CURLOPT_POSTFIELDS => 'grant_type=client_credentials'
    ]);
    
    $response = curl_exec($ch);
    curl_close($ch);
    
    $token_data = json_decode($response, true);
    return $token_data['access_token'] ?? '';
}

// =============== MONCASH ===============
function handleMonCashPayment($data) {
    global $moncash_client_id, $moncash_secret;
    
    $amount = floatval($data['amount'] ?? 1.80);
    $phone = preg_replace('/\D/', '', $data['phone'] ?? '');
    $email = $data['email'] ?? '';
    
    // Получение токена MonCash
    $token_response = getMonCashToken($moncash_client_id, $moncash_secret);
    $access_token = $token_response['access_token'] ?? '';
    
    if (!$access_token) {
        throw new Exception('MonCash authentication failed');
    }
    
    // Создание платежа
    $payment_data = [
        'amount' => $amount,
        'orderId' => 'ORDER_' . time(),
        'redirect_url' => getBaseUrl() . '/payment-success.html',
        'cancel_url' => getBaseUrl() . '/payment-cancel.html'
    ];
    
    $payment_response = createMonCashPayment($access_token, $payment_data);
    
    if (isset($payment_response['payment_url'])) {
        echo json_encode(['payment_url' => $payment_response['payment_url']]);
    } else {
        throw new Exception('MonCash payment creation failed');
    }
}

function getMonCashToken($client_id, $secret) {
    $ch = curl_init();
    curl_setopt_array($ch, [
        CURLOPT_URL => 'https://sandbox.moncashbutton.digicelgroup.com/Api/oauth/token',
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST => true,
        CURLOPT_HTTPHEADER => [
            'Accept: application/json',
            'Authorization: Basic ' . base64_encode("{$client_id}:{$secret}"),
        ],
        CURLOPT_POSTFIELDS => http_build_query(['grant_type' => 'client_credentials'])
    ]);
    
    $response = curl_exec($ch);
    curl_close($ch);
    
    return json_decode($response, true);
}

function createMonCashPayment($access_token, $payment_data) {
    $ch = curl_init();
    curl_setopt_array($ch, [
        CURLOPT_URL => 'https://sandbox.moncashbutton.digicelgroup.com/Api/v1/CreatePayment',
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST => true,
        CURLOPT_HTTPHEADER => [
            'Accept: application/json',
            'Authorization: Bearer ' . $access_token,
            'Content-Type: application/json',
        ],
        CURLOPT_POSTFIELDS => json_encode($payment_data)
    ]);
    
    $response = curl_exec($ch);
    curl_close($ch);
    
    return json_decode($response, true);
}

function getBaseUrl() {
    $protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' ? 'https' : 'http';
    return $protocol . '://' . $_SERVER['HTTP_HOST'];
}
?>