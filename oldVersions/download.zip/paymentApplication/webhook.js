const stripe = require('stripe')('sk_test_your_secret_key');
const express = require('express');
const app = express();

app.post('/webhook', express.raw({type: 'application/json'}), (request, response) => {
    const sig = request.headers['stripe-signature'];
    const endpointSecret = 'whsec_your_webhook_secret';

    let event;

    try {
        event = stripe.webhooks.constructEvent(request.body, sig, endpointSecret);
    } catch (err) {
        response.status(400).send(`Webhook Error: ${err.message}`);
        return;
    }

    // Обработка успешного платежа
    if (event.type === 'payment_intent.succeeded') {
        const paymentIntent = event.data.object;
        console.log('Payment successful:', paymentIntent.id);
        
        // Ваша логика здесь
        handleSuccessfulPayment(paymentIntent);
    }

    response.json({received: true});
});

function handleSuccessfulPayment(paymentIntent) {
    // Обновление БД, активация услуг и т.д.
    const { id, amount, currency, customer } = paymentIntent;
    
    // Пример: обновление статуса в вашей БД
    // await updateOrderStatus(id, 'completed');
}