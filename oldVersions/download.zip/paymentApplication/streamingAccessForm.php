<?php
// streaming-access-form.php
session_start();

// Проверяем, что платеж был успешным
if (!isset($_SESSION['access_data'])) {
    header('Location: /index.html');
    exit;
}

$access_data = $_SESSION['access_data'];
$email_prefix = $access_data['email_prefix'];
$example_email = $access_data['email'];
$unique_access_key = $access_data['access_key'];
$unique_password = $access_data['password'];

// Очищаем сессию после использования
unset($_SESSION['access_data']);
?>
<!DOCTYPE html>
<html>
<head>
    <title>Your Streaming Access</title>
    <style>
        .field{
            display: flex;
            flex-direction: column;
            gap: 10px;
            margin-bottom: 15px;
        }
        form{
            padding: 20px;
            border: 1px solid #ddd;
            border-radius: 10px;
            max-width: 500px;
            margin: 20px auto;
        }
        input{
            padding: 10px;
            border-radius: 5px;
            border: 1px solid #ccc;
            font-family: monospace;
        }
        input:focus{
            border-color: #007bff;
            outline: none;
        }
        h1,h2,h3,h4,h5{
            margin: 0;
            text-align: center;
        }
        .warn{
            color: red;
            font-weight: 600;
        }
        .success{
            color: green;
            font-weight: 600;
        }
        .copy-btn {
            background: #007bff;
            color: white;
            border: none;
            padding: 5px 10px;
            border-radius: 3px;
            cursor: pointer;
            margin-left: 10px;
        }
        .copy-btn:hover {
            background: #0056b3;
        }
    </style>
</head>
<body>
    <h1>🎉 Payment Successful!</h1>
    <h3>Your streaming access details:</h3>
    
    <form id="accessForm" method="POST">
        <div class="field">
            <label>Login</label>
            <div style="display: flex; align-items: center;">
                <input type="text" name="login" value="<?= htmlspecialchars($email_prefix) ?>_konektem" readonly required style="flex: 1;"/>
                <button type="button" class="copy-btn" onclick="copyToClipboard(this.previousElementSibling)">Copy</button>
            </div>
        </div>
        <div class="field">
            <label>Email</label>
            <div style="display: flex; align-items: center;">
                <input type="email" name="email" value="<?= htmlspecialchars($example_email) ?>" readonly required style="flex: 1;"/>
                <button type="button" class="copy-btn" onclick="copyToClipboard(this.previousElementSibling)">Copy</button>
            </div>
        </div>
        <div class="field">
            <label>Access Key</label>
            <div style="display: flex; align-items: center;">
                <input type="text" name="accessKey" value="viewer_<?= htmlspecialchars($unique_access_key) ?>" readonly required style="flex: 1;"/>
                <button type="button" class="copy-btn" onclick="copyToClipboard(this.previousElementSibling)">Copy</button>
            </div>
        </div>
        <div class="field">
            <label>Password</label>
            <div style="display: flex; align-items: center;">
                <input name="password" type="text" value="<?= htmlspecialchars($unique_password) ?>" readonly required style="flex: 1;"/>
                <button type="button" class="copy-btn" onclick="copyToClipboard(this.previousElementSibling)">Copy</button>
            </div>
        </div>
    </form>

    <div id="message" style="text-align: center; margin-top: 20px;"></div>
</body>
<script>
    document.addEventListener('DOMContentLoaded', () => {
        const form = document.getElementById('accessForm');
        
        if(isFormComplete(form)){
            let xhr = new XMLHttpRequest();
            
            const getResponse = new Promise((resolve, reject) => {
                xhr.open('POST', "/php/viewerReg.php", true);
                xhr.responseType = 'json';
                xhr.onreadystatechange = function() {
                    if(xhr.readyState === 4) {
                        if(xhr.status >= 200 && xhr.status < 300) {
                            resolve(xhr.response);
                        } else {
                            reject({status: xhr.status, reason: xhr.statusText});
                        }
                    }
                };
                let formData = new FormData(form);
                xhr.send(formData);
            });
            
            getResponse.then(response => {
                if(response.success) {
                    let messageDiv = document.getElementById('message');
                    messageDiv.innerHTML = `
                        <h2 class="success">✅ Access Granted!</h2>
                        <h3>Save your stream key and password - they will disappear when you close this tab</h3>
                        <h4><i>Thank you for choosing KONEKTEM</i></h4>
                        <h5 class="warn">Key will expire on ${response.expiration_date}</h5>
                        <p><strong>Important:</strong> Copy and paste this information to access Konektem live streams</p>
                    `;
                    
                    // Автоматически прокручиваем к сообщению
                    messageDiv.scrollIntoView({ behavior: 'smooth' });
                } else {
                    console.error('Registration failed:', response);
                    alert('Registration failed: ' + (response.error || 'Unknown error'));
                }
            }).catch(err => {
                console.error('Request failed:', err);
                alert('Error: ' + err.reason);
            });
        } else {
            alert("Form is not complete");
            return;
        }

        function isFormComplete(form) {
            let formData = new FormData(form);
            for(const [key, value] of formData.entries()) {
                if(value.length === 0) {
                    alert("Missing field: " + key);
                    return false;
                }
            }
            return true;
        }
    });

    // Функция для копирования в буфер обмена
    function copyToClipboard(inputElement) {
        inputElement.select();
        inputElement.setSelectionRange(0, 99999); // Для мобильных устройств
        
        try {
            navigator.clipboard.writeText(inputElement.value).then(() => {
                // Визуальная обратная связь
                const originalText = inputElement.nextElementSibling.textContent;
                inputElement.nextElementSibling.textContent = 'Copied!';
                inputElement.nextElementSibling.style.background = '#28a745';
                
                setTimeout(() => {
                    inputElement.nextElementSibling.textContent = originalText;
                    inputElement.nextElementSibling.style.background = '#007bff';
                }, 2000);
            });
        } catch (err) {
            // Fallback для старых браузеров
            document.execCommand('copy');
            alert('Copied to clipboard!');
        }
    }
</script>
</html>