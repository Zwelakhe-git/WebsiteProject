function paymentsHtml(){
    return ``;
}

function paymentScript(){
        const { useState, useEffect } = React;

        // REAL KEYS
        const STRIPE_PUBLISHABLE_KEY = 'pk_live_51S5ug9DtuiWMVJmJbv8rxKPGvRpz9WPbnKTPLiPaDqf3JRFkmSfZUawO51HQf4mE2ZP9J0K4nQDIu3tamUzoT00700M2PpG7U8';
        const PAYPAL_CLIENT_ID = 'ATDZGyNpLtB6ZRo4FRQ1w9YrNq7CmQh1QayQfwZIWnPM7lhaWqWQRl9tN6rLoRKyYdIsmxEZ5tfUj8uY';

        const stripe = Stripe(STRIPE_PUBLISHABLE_KEY);

        const PaymentPage = () => {
            const [cardName, setCardName] = useState('');
            const [email, setEmail] = useState('');
            const [phone, setPhone] = useState('');
            const [activeMethod, setActiveMethod] = useState('card');
            const [isProcessing, setIsProcessing] = useState(false);
            const [paymentStatus, setPaymentStatus] = useState({ type: '', message: '' });
            const [cardElement, setCardElement] = useState(null);

            // Stripe Elements when card method is selected
            useEffect(() => {
                if (activeMethod === 'card') {
                    const elements = stripe.elements();
                    const card = elements.create('card', {
                        style: {
                            base: {
                                fontSize: '16px',
                                color: '#333',
                                '::placeholder': { color: '#aaa' },
                            },
                            invalid: { color: '#fa755a' },
                        },
                    });
                    card.mount('#card-element');
                    setCardElement(card);
                }
            }, [activeMethod]);

            // Load PayPal SDK
            useEffect(() => {
                if (activeMethod === 'paypal' && !window.paypal) {
                    const script = document.createElement('script');
                    script.src = `https://www.paypal.com/sdk/js?client-id=${PAYPAL_CLIENT_ID}&currency=USD`;
                    script.async = true;
                    document.body.appendChild(script);
                }
            }, [activeMethod]);

            const handleSubmit = async (e) => {
                e.preventDefault();
                setIsProcessing(true);
                setPaymentStatus({ type: '', message: '' });

                try {
                    if (activeMethod === 'card') {
                        await processCardPayment();
                    } else if (activeMethod === 'paypal') {
                        await processPaypalPayment();
                    } else if (activeMethod === 'moncash') {
                        await processMonCashPayment();
                    } else if (activeMethod === 'applepay') {
                        await processApplePayPayment();
                    }
                } catch (error) {
                    console.error('Payment error:', error);
                    setPaymentStatus({ type: 'error', message: `Payment failed: ${error.message || 'Unknown error'}` });
                } finally {
                    setIsProcessing(false);
                }
            };

            // =============== STRIPE CARD (with Elements) ===============
            const processCardPayment = async () => {
                if (!cardName || !email) {
                    throw new Error('Please enter cardholder name and email');
                }

                const res = await fetch('/api/create-payment-intent', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ amount: 100, currency: 'usd', email })
                });
                const { clientSecret } = await res.json();
                if (!res.ok) throw new Error('Failed to create payment');

                const { error, paymentIntent } = await stripe.confirmCardPayment(clientSecret, {
                    payment_method: {
                        card: cardElement, // ← Stripe Element, not raw data
                        billing_details: { name: cardName, email }
                    }
                });

                if (error) throw new Error(error.message);
                setPaymentStatus({ type: 'success', message: `✅ Card payment succeeded! ID: ${paymentIntent.id}` });
            };

            // =============== PAYPAL ===============
            const processPaypalPayment = async () => {
                return new Promise((resolve, reject) => {
                    const container = document.createElement('div');
                    container.id = 'paypal-button-container';
                    document.body.appendChild(container);

                    window.paypal.Buttons({
                        createOrder: async () => {
                            const res = await fetch('/api/paypal-create-order', {
                                method: 'POST',
                                headers: { 'Content-Type': 'application/json' },
                                body: JSON.stringify({ amount: '119.80', currency: 'USD', email })
                            });
                            const data = await res.json();
                            return data.id;
                        },
                        onApprove: async (data) => {
                            const res = await fetch('/api/paypal-capture-order', {
                                method: 'POST',
                                headers: { 'Content-Type': 'application/json' },
                                body: JSON.stringify({ orderID: data.orderID })
                            });
                            const details = await res.json();
                            if (res.ok) {
                                setPaymentStatus({ type: 'success', message: `✅ PayPal payment completed! ID: ${details.id}` });
                                resolve();
                            } else {
                                reject(new Error('PayPal capture failed'));
                            }
                        },
                        onError: reject,
                        onCancel: () => reject(new Error('User canceled PayPal'))
                    }).render('#paypal-button-container');
                });
            };

            // =============== MONCASH ===============
            const processMonCashPayment = async () => {
                if (!phone || phone.replace(/\D/g, '').length < 8) {
                    throw new Error('Valid phone number required');
                }

                const res = await fetch('/api/moncash-create-payment', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ amount: 119.80, phone: phone.replace(/\D/g, ''), email })
                });
                const { payment_url } = await res.json();
                if (!res.ok) throw new Error('MonCash request failed');

                window.location.href = payment_url;
            };

            // =============== APPLE PAY ===============
            const processApplePayPayment = async () => {
                if (!window.ApplePaySession || !ApplePaySession.canMakePayments()) {
                    throw new Error('Apple Pay not available');
                }

                const res = await fetch('/api/create-payment-intent', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ amount: 100, currency: 'usd', email })
                });
                const { clientSecret } = await res.json();

                const { error, paymentIntent } = await stripe.confirmApplePayPayment(clientSecret, {
                    paymentMethodData: { billingDetails: { email } }
                });

                if (error) throw new Error(error.message);
                setPaymentStatus({ type: 'success', message: `✅ Apple Pay succeeded! ID: ${paymentIntent.id}` });
            };

            return (
                <div className="payment-container">
                    <div className="header">
                        <h1>Secure Online Payments</h1>
                        <p>Fast and secure payment processing for your purchases</p>
                    </div>
                    <div className="payment-content">
                        <div className="payment-form">
                            <h2 className="section-title">Payment Method</h2>
                            <div className="payment-methods">
                                <div className={`payment-method ${activeMethod === 'card' ? 'active' : ''}`} onClick={() => setActiveMethod('card')}>
                                    <span className="icon">💳</span>
                                    <span className="name">Credit Card</span>
                                </div>
                                <div className={`payment-method ${activeMethod === 'paypal' ? 'active' : ''}`} onClick={() => setActiveMethod('paypal')}>
                                    <span className="icon">📱</span>
                                    <span className="name">PayPal</span>
                                </div>
                                <div className={`payment-method ${activeMethod === 'moncash' ? 'active' : ''}`} onClick={() => setActiveMethod('moncash')}>
                                    <span className="icon">💸</span>
                                    <span className="name"><span className="moncash-logo">Mon Cash</span></span>
                                </div>
                                <div className={`payment-method ${activeMethod === 'applepay' ? 'active' : ''}`} onClick={() => setActiveMethod('applepay')}>
                                    <span className="icon">🍎</span>
                                    <span className="name">Apple Pay</span>
                                </div>
                            </div>
                            <form onSubmit={handleSubmit}>
                                {activeMethod === 'paypal' && (
                                    <div className="form-group">
                                        <label>PayPal Payment</label>
                                        <div id="paypal-button-container"></div>
                                    </div>
                                )}
                                
                                {activeMethod === 'card' && (
                                    <>
                                        <div className="form-group">
                                            <label>Card Details</label>
                                            <div id="card-element"></div>
                                        </div>
                                        <div className="form-group">
                                            <label>Cardholder Name</label>
                                            <input type="text" className="form-control" placeholder="JOHN DOE"
                                                value={cardName} onChange={(e) => setCardName(e.target.value)} required />
                                        </div>
                                        <div className="form-group">
                                            <label>Email for receipt</label>
                                            <input type="email" className="form-control" placeholder="email@example.com"
                                                value={email} onChange={(e) => setEmail(e.target.value)} required />
                                        </div>
                                    </>
                                )}
                                {activeMethod === 'paypal' && (
                                    <div className="form-group">
                                        <p>After clicking "Pay Now", you will be redirected to PayPal to complete your payment securely.</p>
                                    </div>
                                )}
                                {activeMethod === 'moncash' && (
                                    <div className="form-group">
                                        <label>Phone Number</label>
                                        <input type="tel" className="form-control" placeholder="Your Mon Cash phone number"
                                            value={phone} onChange={(e) => setPhone(e.target.value)} required />
                                        <p style={{marginTop: '10px', fontSize: '14px', color: '#666'}}>
                                            Enter your Mon Cash registered phone number. You will receive a confirmation prompt on your device.
                                        </p>
                                    </div>
                                )}
                                {activeMethod === 'applepay' && (
                                    <div className="form-group">
                                        <p>After clicking "Pay Now", the Apple Pay window will open to complete your payment.</p>
                                    </div>
                                )}
                                <button type="submit" className="btn" disabled={isProcessing}>
                                    {isProcessing ? <span className="loading"></span> : 'Pay Now'}
                                </button>
                                {paymentStatus.message && (
                                    <div className={`payment-status ${paymentStatus.type}`}>{paymentStatus.message}</div>
                                )}
                                <div className="secure-notice">🔒 Your data is securely protected</div>
                            </form>
                        </div>
                        <div className="payment-summary">
                            <h2 className="section-title">Order Summary</h2>
                            <div className="summary-item"><span>Products</span><span>$0.00</span></div>
                            <div className="summary-item"><span>Shipping</span><span>$0.00</span></div>
                            <div className="summary-item"><span>Tax</span><span>$0.80</span></div>
                            <div className="summary-total"><span>Total</span><span>$1.80</span></div>
                            <div className="info-box">
                                <h3>Money-Back Guarantee</h3>
                                <p>If you're not satisfied with your purchase, we offer a 30-day money-back guarantee with no questions asked.</p>
                            </div>
                            <div className="info-box">
                                <h3>Customer Support</h3>
                                <p>Phone: +1 (800) 123-4567</p>
                                <p>Email: support@example.com</p>
                                <p>Hours: Mon-Fri, 9am-6pm EST</p>
                            </div>
                        </div>
                    </div>
                </div>
            );
        };

        const App = () => <PaymentPage />;
        const root = ReactDOM.createRoot(document.getElementById('root'));
        root.render(<App />);
}

var scripts = [
    {
        type: "text/javascript",
        src: "https://unpkg.com/react-dom@18/umd/react-dom.development.js"
    },
    {
        type: "text/javascript",
        src: "https://unpkg.com/react@18/umd/react.development.js"
    },
    {
        type: "text/javascript",
        src: "https://unpkg.com/@babel/standalone/babel.min.js"
    },
    {
        type: "text/javascript",
        src: "https://js.stripe.com/v3/"
    }
]

let styles = [
    {
        type: "text/css",
        href: "/paymentApplication/css/style.css"
    }
]


export default function  paymentsPage(){
    let title = document.head.querySelector("title");
    if(!title){
        title = document.createElement("title");
        document.head.insertAdjacentElement("afterbegin", title);
    }
    title.textContent = "Konektem Payment";

    styles.forEach( style => {
        let linktag = document.createElement("link");
        linktag.type = style.type;
        linktag.href = style.href;
        document.head.appendChild(linktag);
    });


    scripts.forEach( script => {
        let scriptTag = document.createElement("script");
        scriptTag.type = script.type;
        scriptTag.src = script.src;

        document.head.appendChild(scriptTag);
    }
    );

    setTimeout( () => {
        paymentScript();
    }, 200);
}
