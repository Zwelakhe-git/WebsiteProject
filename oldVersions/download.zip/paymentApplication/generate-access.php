<?php
// generate-access.php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type');

$input = json_decode(file_get_contents('php://input'), true);
$payment_id = $input['payment_id'] ?? '';
$email = $input['email'] ?? '';

if (empty($payment_id) || empty($email)) {
    echo json_encode(['success' => false, 'error' => 'Missing data']);
    exit;
}

$uid = uniqid();
$len = strlen($uid);

// Генерируем массив из случайных 6 индексов
$indexes = array_rand(range(0, $len - 1), 6);

sort($indexes);

$result = '';
foreach ($indexes as $i) {
    $result .= $uid[$i];
}
// Генерация данных доступа
$email_prefix = substr($email, 0, strpos($email, '@')) . '_' . $result;
$unique_access_key = bin2hex(random_bytes(16));
$unique_password = substr(md5(uniqid()), 0, 8);

$access_data = [
    'login' => $email_prefix . '_konektem',
    'email' => $email,
    'access_key' => 'viewer_' . $unique_access_key,
    'password' => $unique_password,
    'payment_id' => $payment_id
];

// Сохраняем в базу данных (рекомендуется)
saveAccessDataToDatabase($access_data);

echo json_encode([
    'success' => true,
    'access_data' => $access_data
]);

function saveAccessDataToDatabase($data) {
    // Ваш код для сохранения в БД
    // Например: 
    // $pdo = new PDO(...);
    // $stmt = $pdo->prepare("INSERT INTO streaming_access (...) VALUES (...)");
    // $stmt->execute([...]);
    
    // Пока просто сохраняем в файл для примера
    file_put_contents('access_log.txt', 
        date('Y-m-d H:i:s') . " - " . json_encode($data) . "\n", 
        FILE_APPEND
    );
}
?>