<?php
// payment-handler.php
function handleStripePaymentIntent($data) {
    $amount = intval($data['amount']);
    $currency = $data['currency'] ?? 'usd';
    $email = $data['email'] ?? '';

    try {
        $paymentIntent = \Stripe\PaymentIntent::create([
            'amount' => $amount,
            'currency' => $currency,
            'receipt_email' => $email,
            'automatic_payment_methods' => ['enabled' => true],
        ]);

        // ВАЖНО: Возвращаем clientSecret
        echo json_encode([
            'success' => true,
            'clientSecret' => $paymentIntent->client_secret,
            'paymentIntentId' => $paymentIntent->id
        ]);

    } catch (Exception $e) {
        echo json_encode([
            'success' => false,
            'error' => $e->getMessage()
        ]);
    }
}
?>