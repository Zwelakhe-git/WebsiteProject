<?php
define('WHSEC','whsec_uXD7isyVu25DfjrvUb3ZR6JhVPM7g2YR');
define("SK_LIVE", "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");
?>