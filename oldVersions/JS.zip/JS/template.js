
function topBar(){
    return `<div id="top-bar" class="no-margin flxDisp">
          <div class="top-bar-container">
            <div id="logo">
              <img alt="logo" type="image/jpg" width="50" height="50" src="/media/images/Konektem.png"/>
            </div>
            <div id="top-bar-content" class="flxDisp full-h"></div>
          </div>
        </div>`;
}

function head(){
    return `
    <div id="head">
          <div id="news-slides">
            <div class="slide-image-container full-w-h">
              <img alt="news image" src="/media/images/hqdefault.png" class="slide-image cvr full-w" />
              <p class="slide-img-desc">DESCRIPTION</p>
            </div>
            <div class="slide-image-container full-w-h">
              <img alt="news image" src="/media/images/hq723.png" class="slide-image cvr full-w" />
              <p class="slide-img-desc">
                President Donald Trump and Ukrainian President Volodymyr Zelenskyy sounded positive as they met at 
                the White House on Monday as Trump pushes for an end to Russia's war on Kyiv.
              </p>
            </div>
            <div class="slide-image-container full-w-h">
              <img alt="news image" src="/media/images/hq720_2.jpg" class="slide-image cvr full-w" />
              <p class="slide-img-desc">DESCRIPTION</p>
            </div>
            <div class="slide-image-container full-w-h">
              <img alt="news image" src="/media/images/hq720.jpg" class="slide-image cvr full-w" />
              <p class="slide-img-desc">DESCRIPTION</p>
            </div>
          </div>
          <div class="scroll-btn right">
          </div>
          <div class="scroll-btn left">
          </div>
        </div>`;
}

function navPanel(){
    return `<div id="nav-panel" class="grey-clr no-ovrflw no-margin">
          <nav class="no-ovrflw">
            <a tabindex="0" class="bdr-10" href="/actuality.html">
              <ion-icon name="calendar-clear-outline"></ion-icon>
              <span>Actuality</span>
            </a>
            <a tabindex="0" href="/charts.html" class="bdr-10">
              <ion-icon name="bar-chart-outline"></ion-icon>
              <span>Music Charts</span>
            </a>
            <a tabindex="0" href="#services-panel" class="bdr-10">
              Services
            </a>
            <a tabindex="0" class="bdr-10" href="http://localhost:8080/livestream.html">
              <ion-icon name="radio-outline"></ion-icon>
              <span>Live Streaming</span>
            </a>
            <a tabindex="0" class="bdr-10">
              <ion-icon name="search-outline"></ion-icon>
              <span>Events</span>
            </a>
            <a tabindex="0" class="bdr-10">Join Us</a>
          </nav>
        
        </div>`;
}

function lastNews(){
    return `
    <div id="last-news" class="margin-rl-1">
          <div class="section-info">
            <a href="/actuality.html"><h1>LATEST NEWS</h1></a>
          </div>
          <div class="articles"></div>
          <a>
            <div class="more-actions">
              <span>see all</span>
              <ion-icon name="arrow-forward-outline"></ion-icon>
            </div>
          </a>
        </div>`;
}

function eventsSection(){
    return `
    <div id="events-section" class="margin-rl-1 colDir">
          <div id="events-section-bg" class="full-h"></div>
          <div class="section-info">
            <a href="#"><h1>EVENTS</h1></a>
          </div>
          <div id="events-list">
          </div>
          <a>
            <div class="more-actions">
              <span>see all</span>
              <ion-icon name="arrow-forward-outline"></ion-icon>
          </div>
          </a>
        </div>`;
}

function middlePanel(){
    return `
    <div id="middle-panel" class="margin-rl-1 colDir">
          <div class="section-info">
              <a href="/charts.html">
                <h1>
                  VIDEOS AND CHARTS
                </h1>
              </a>
            </div>
          <div id="music-charts-video" class="flxDisp colDir">
            <!-- new update: combine charts and videos -->
            
            <div class="media-row-content charts">
               <div class="section-info charts-title">
                <h2>TOP CHARTS</h2>
               </div>
              <div class="audio-charts"></div>
              <div class="more-actions">
                <span>see all</span>
                <ion-icon name="arrow-forward-outline"></ion-icon>
              </div>
            </div>
            <div class="media-row-content">
               <div class="section-info vids-title">
                <h2>POPULAR VIDOES</h2>
               </div>
              <div class="music-videos">
              </div>
            </div>
          </div>
        </div>`;
}

function rightPanel(){
    return `
    <div id="right-panel" class="margin-rl-1">
          <div id="essentials-section">
            <div class="section-info">
              <a href="/actuality.html"><h1>ESSENTIALS</h1></a>
            </div>
            <div id="link-portrait-video">
            </div>
          </div>
        </div>`;
}

function servicesPanel(){
    return `
    <div id="services-panel" class="margin-rl-1">
          <div class="section-info">
            <a href="#"><h1>SERVICES</h1></a>
          </div>
          <!-- preparing containers for pasting -->
          <div id="services-list"></div>
          <div class="more-actions">
            <span>see all</span>
            <ion-icon name="arrow-forward-outline"></ion-icon>
          </div>
        </div>`;
}

function tmpVide(){
    return `
    <div id="tmp-vid">
          <div class="section-info">
            <h1>What success on Konektem looks like</h1>
          </div>
          <video type="video/mp4" src="/media/videos/file.mp4" poster="" autoplay muted loop controls>
            Browser does not support the &gt;video> element
          </video>
        </div>`;
}

function partnersPanel(){
    return `
    <div id="partners-panel" class="margin-rl-1">
          <div class="section-info">
            <h1>
              PARTNERS
            </h1>
          </div>
          
        </div>`;
}

function footer(){
    return `
    <div id="footer" class="white-clr no-margin flxDisp">
          <div id="about-company">
            <h1>Who we are</h1>
            <div id="text-info"></div>
          </div>
          <div id="contact-information">
            <h1>Contacts</h1>
            <div id="contacts-links">
              <div id="social-media-links">
                <a><ion-icon name="logo-facebook"></ion-icon></a>
                <a><ion-icon name="logo-instagram"></ion-icon></a>
                <a><ion-icon name="logo-youtube"></ion-icon></a>
              </div>
            </div>
          </div>
        </div>`;
}

function notifyAboutWinSize(){
    let innerW = window.outerWidth;
    let innerH = window.outerHeight;
    let outerW = window.outerWidth;
    let outerH = window.outerHeight;
    let root = document.querySelector("#root");
    if(innerW < 768){
        root.innerHTML = `<span>Mobile view:innerWidth: ${innerW}, outerWidth: ${outerW}</span>
        <span>innerHeight: ${innerH}, outerHeight: ${outerH}`;
    }
    else if( innerW < 1024 ){
        root.innerHTML = `<span>tablet view:innerWidth: ${innerW}, outerWidth: ${outerW}</span>
        <span>innerHeight: ${innerH}, outerHeight: ${outerH}`;
    }
    else{
        root.innerHTML = `<span>desktop view:innerWidth: ${innerW}, outerWidth: ${outerW}</span>
        <span>innerHeight: ${innerH}, outerHeight: ${outerH}`;
    }
}

let resizeTimeout = null;

function loadPageContents(){
    let root = document.querySelector("#root");
    notifyAboutWinSize();
}

document.addEventListener("DOMContentLoaded", loadPageContents);

window.addEventListener("resize", () => {
    clearTimeout(resizeTimeout);
    resizeTimeout = setTimeout(notifyAboutWinSize, 250);
});
