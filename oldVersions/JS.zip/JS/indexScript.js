
document.addEventListener("DOMContentLoaded", ()=>{
    // const script1 = document.createElement("script");
    // const script2 = document.createElement("script");
    // script1.src = "https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.esm.js"
    // script1.type = "module";
    // script2.src = "https://unpkg.com/ionicons@7.1.0/dist/ionicons/ionicons.js";
    // script2.noModule = true;

    // document.body.insertAdjacentElement("beforeend", script2);
    // document.body.insertBefore(script1, script2);
    
    const waitForServicesToLoad = () => {
        return new Promise((resolve) => {
            const observer = new MutationObserver(() => {
                const servicesList = document.querySelectorAll("#services-panel li");
                if(servicesList.length > 0){
                    observer.disconnect();
                    resolve(servicesList);
                }
            });
            observer.observe(document.body, { childList : true, subtree: true });
        });
    }
    waitForServicesToLoad().then(servicesList => {
        if(servicesList.length > 0){
            servicesList[0].classList.add("selected");
            servicesList.forEach(li => {
                li.addEventListener("click", () => {
                    
                    document.querySelectorAll("#about-service p").forEach( p => {
                        p.style.display = (p.getAttribute("for") !== li.getAttribute("id") ? "none": "block");
                    } );
                    servicesList.forEach(other => {
                        other.classList.remove("selected");
                    });
                    li.classList.add("selected");
                });
            });
        }
    });
    
    let vidLinks = document.querySelectorAll("a.video-link");
    vidLinks.forEach( a => {
        let url = "/videos.html?";
        
        let vidElement = a.querySelector(".vid-item video");
        let safeVidPath = encodeURIComponent(vidElement.getAttribute("src"));
        let safeImgPath = encodeURIComponent(vidElement.getAttribute("poster"));
        url += `imgURL=${safeImgPath}&vidURL=${safeVidPath}`;
        a.href = url;
    })
    
});