const MAX_NEWS_FADE_CONTENT = 20;
const MAX_EVENT_CONTENT = 6;
const MAX_MUSIC_CONTENT = 5;
let count = 0;
function indexPageLoader(){
    return new Promise(resolve => {
        let xmlHttp = null;
        if(window.ActiveXObject){
            xmlHttp = new ActiveXObject();
        }
        else{
            xmlHttp = new XMLHttpRequest();
        }

        if(!xmlHttp){
            console.log("Failed to create request object");
            exit();
        }
        xmlHttp.responseType = "json";
        sendRequest();

        function sendRequest(){
            if(xmlHttp.readyState == 4 || xmlHttp.readyState == 0){
                try{
                    xmlHttp.open("GET","/php/dbReader.php?r=all", true);
                    xmlHttp.send(null);
                    xmlHttp.onreadystatechange = resposeHandler;
                }catch(e){
                    alert("Exception when sending request");
                }
            }
        }

        function resposeHandler(){
            if(xmlHttp.readyState == 4){
                if(xmlHttp.status === 200){
                    let response = xmlHttp.response;
                    if(typeof response === "object"){
                        for(const [contentName, content] of Object.entries(response)){
                            let container = null;
                            let targetContainer = null;

                            switch(contentName){

                                case "services":
                                    container = document.querySelector("#services-list");
                                    let inlineHTML = "";
                                    for(const index in content){
                                        inlineHTML += `<div class="serv-container">
                                            <div class="service-desc">
                                            <span>${content[index].name}</span>
                                            </div>
                                            <div class="service-img">
                                                <div class="service-img-cont">
                                                    <img alt="service-img" src="${content[index].image_location}"/>
                                                </div>
                                            </div>
                                        </div>`;
                                    }
                                    container.innerHTML = inlineHTML;
                                    break;

                                case "news":
                                    targetContainer = document.querySelector(".articles");
                                    if(!targetContainer){
                                        console.log("news container is empty. check your CSS selector");
                                        break;
                                    }
                                    count = 0;
                                    for(const index in content){
                                        if(count >= MAX_NEWS_FADE_CONTENT){
                                            break;
                                        }
                                        
                                        container = document.createElement("div");
                                        container.classList.add("news-content", "full-w", "flxDisp");
                                        const article = document.createElement("article");
                                        article.appendChild(container);
                                        article.classList.add("flxDisp", "full-w", "artcl-itm");
                                        let inlineHTML = `
                                        <a href="" class="news-content-link flxDisp">
                                        <img class="news-img" src="${content[index].image_location}" alt="news cover image">
                                        <div class="news-image-background" style="background-image:url('${content[index].image_location}')"></div>
                                        </a>
                                        `;
                                        inlineHTML += `<div class="news-headline flxDisp no-margin">
                                            <h1 class="no-margin">${content[index].newsTitle}</h1>
                                            <p class="news-a">${content[index].newsContent}</p>
                                            <div class="flxDisp artc-info">
                                            <ion-icon class="news-tm" name="time-outline"></ion-icon>
                                            <span class="date">${content[index].newsDate}</span>
                                            </div>
                                        </div>`;
                                        container.innerHTML = inlineHTML;
                                        targetContainer.appendChild(article);
                                        ++count;
                                    }
                                    break;
                                case "events":
                                    targetContainer = document.querySelector("#events-list");
                                    count = 0;
                                    for(const index in content){
                                        if(count >= MAX_EVENT_CONTENT){
                                            break;
                                        }
                                        const card = document.createElement("div");
                                        card.className = "event-card";
                                        card.innerHTML = `<div class="ev-container">
                                            <img src="${content[index].image_location}" alt="${content[index].title}" class="event-image" />
                                            <div class="event-content">
                                            <div class="ticket-info">
                                            <span>Ticket Price</span>
                                            <span class="ticket-price">\$${content[index].price}</span>
                                            </div>
                                            <a href="#" class="buy-btn">Buy Ticket</a>
                                            </div>
                                            </div>
                                        `;
                                        targetContainer.appendChild(card);
                                    }
                                    break;
                                case "musicContent":
                                    targetContainer = document.querySelector(".audio-charts");
                                    if(!targetContainer){
                                        console.log("audio charts container not found");
                                        return;
                                    }
                                    let minlineHTML = "";
                                    count = 0;
                                    for(const index in content){
                                        if(count >= MAX_MUSIC_CONTENT){
                                            break;
                                        }
                                        let formattedName = content[index].track_name.replaceAll(" ","_");
                                        minlineHTML += `<div class="track"
                                        id="track-${content[index].id}"
                                        ${content[index].location.length > 0 && `data-src="${content[index].location}"`  }>
                                            <div class="track-img">
                                                <img class="full-w-h" alt="track image" src="${content[index].image_location}" />
                                            </div>
                                            <div class="music-info">
                                                <div class="music-title">${content[index].track_name}</div>
                                                <div class="music-artist">${content[index].artist_name}</div>
                                                <div class="player-controls">
                                                    <div class="play-btn" data-trackid="track-${content[index].id}">
                                                        <i class="fas fa-play media-ico play"
                                                        data-trackid="track-${content[index].id}"
                                                        ${content[index].location.length > 0 && `data-src="${content[index].location}"`  }
                                                        data-tracktitle=${formattedName}></i>
                                                    </div>
                                                    <div class="progress-bar">
                                                        <div class="progress track-${content[index].id}"></div>
                                                    </div>
                                                    <div class="music-duration track-${content[index].id}"></div>
                                                </div>
                                                <div class="media-actions">
                                                    <div class="action-btn download-btn">
                                                        <i class="fas fa-download media-ico" data-trackid="${content[index].id}" data-tracktitle="${formattedName}"></i>
                                                        <span>${content[index].downloads}</span>
                                                    </div>
                                                    <div class="action-btn like-btn">
                                                        <i class="fa-regular fa-heart media-ico" data-tracktitle="${formattedName}"></i>
                                                        <span>${content[index].likes}</span>
                                                    </div>
                                                    <div class="action-btn plays-btn">
                                                        <ion-icon name="eye-outline" class="media-ico" data-tracktitle=${formattedName}></ion-icon>
                                                        <span>${content[index].plays}</span>
                                                    </div>
                                                </div>
                                            </div>                                            
                                        </div>`  
                                        ++count;
                                    }
                                    //<audio id="track-${content[index].id}" class="html-aud" ${content[index].location.length > 0 && `src="${content[index].location}"`  }></audio>
                                    targetContainer.innerHTML += minlineHTML;
                                    break;
                                default:
                                    //customFillServices();
                                    //customFillEvents();

                                    break;
                            }
                        }
                        resolve(true);
                    }
                    else{
                        alert("Unexpected response type. expected " + xmlHttp.responseType);
                    }
                }else{
                    console.log("Failed to connect to server. error code : " + xmlHttp.status);
                }
            }
        }
    })
    
};

function customFillEvents(){
    let myEvents = [
        {
            title: "Summer Music Festival",
            date: "Sep 28, 2025 – 7:00 PM",
            price: "$45",
            eventImage: "/media/images/events/photo_5082859079608240904_y.jpg",
            eventurl: "#"
        },
        {
            title: "Jazz Night Live",
            date: "Oct 10, 2025 – 9:00 PM",
            price: "$30",
            eventImage: "/media/images/events/photo_5082859079608240905_y.jpg",
            eventurl: "#"
        },
        {
            title: "Electro Beats Party",
            date: "Oct 21, 2025 – 11:00 PM",
            price: "$60",
            eventImage: "/media/images/events/photo_5082859079608240906_y.jpg",
            eventurl: "#"
        },
        {
            title: "Summer Music Festival",
            date: "Sep 28, 2025 – 7:00 PM",
            price: "$45",
            eventImage: "/media/images/events/photo_5082859079608240907_y.jpg",
            eventurl: "#"
        },
        {
            title: "Jazz Night Live",
            date: "Oct 10, 2025 – 9:00 PM",
            price: "$30",
            eventImage: "/media/images/events/photo_5082859079608240908_y.jpg",
            eventurl: "#"
        },
        {
            title: "Electro Beats Party",
            date: "Oct 21, 2025 – 11:00 PM",
            price: "$60",
            eventImage: "/media/images/events/photo_5082859079608240909_y.jpg",
            eventurl: "#"
        }
    ]
    var targetContainer = document.querySelector("#events-list");
    for(const index in myEvents){
        const card = document.createElement("div");
        card.className = "event-card";
        card.innerHTML = `<div class="ev-container">
            <img src="${myEvents[index].eventImage}" alt="${myEvents[index].title}" class="event-image" />
            <div class="event-content">
            <div class="ticket-info">
            <span>Ticket Price</span>
            <span class="ticket-price">${myEvents[index].price}</span>
            </div>
            <a href="${myEvents[index].eventurl}" class="buy-btn">Buy Ticket</a>
            </div>
            </div>
        `;
        targetContainer.appendChild(card);
    }
}


function fillAudioCharts(){
    const tracks = [
        {
            trackimg : "/media/images/music/eminemBtflP.png",
            artist : "Eminem",
            title : "Beautiful Pain",
            src : "/media/audio/Beautiful Pain.mp3"
        },
        {
            trackimg : "/media/images/music/akonFreedom.jpg",
            artist : "Akon",
            title : "Freedom",
            src : ""
        },
        {
            trackimg : "/media/images/music/BIGJuicy.png",
            artist : "B.I.G",
            title : "Juicy",
            src : ""
        },
        {
            trackimg : "/media/images/music/akonTroubMakers.jpg",
            artist : "Akon",
            title : "TroubleMakers",
            src : ""
        },
        {
            trackimg : "/media/images/music/photo_5084623735641279382_y.jpg",
            artist : "The Weekend",
            title : "Save Your Tears",
            src : ""
        }
    ]
    let targetContainer = document.querySelector(".audio-charts");
    if(!targetContainer){
        console.log("audio charts container not found");
        return;
    }

    for(const [i, track] of tracks.entries()){
        let inlineHTML = `<div class="track">
            <div class="track-img">
                <img class="full-w-h" alt="track image" src="${track.trackimg}" />
            </div>
            <div class="music-info">
                <div class="music-title">${track.title}</div>
                <div class="music-artist">${track.artist}</div>
                <div class="player-controls">
                    <div class="play-btn" data-trackid="track-${i+1}">
                        <i class="fas fa-play" data-trackid="track-${i+1}"></i>
                    </div>
                    <div class="progress-bar">
                        <div class="progress track-${i+1}"></div>
                    </div>
                    <div class="music-duration track-${i+1}"></div>
                </div>
                <div class="media-actions">
                    <div class="action-btn download-btn">
                        <i class="fas fa-download media-ico" data-tracktitle="${track.title.split(" ").join("_")}"></i>
                        <span>20k</span>
                    </div>
                    <div class="action-btn like-btn">
                    	<i class="fa-regular fa-heart media-ico" data-tracktitle="${track.title.split(" ").join("_")}"></i>
                        <span>10k</span>
                    </div>
                    <div class="action-btn plays-cnt">
                    	<ion-icon name="eye-outline" class="media-ico"></ion-icon>
                        <span>50k</span>
                    </div>
                </div>
            </div>
            <audio id="track-${i+1}" class="html-aud" ${track.src.length > 0 ? `src="${track.src}"` : ""}></audio>
        </div>`
        targetContainer.innerHTML += inlineHTML;
    }
}

function customFillServices(){
    let targetCotainer = document.querySelector("#services-list");
    if(!targetCotainer){
        console.log("services container not found");
        exit(-1);
    }
    let services = [
        {
            name : "service name",
            Img : ""
        },
        {
            name : "service name",
            Img : ""
        },
        {
            name : "service name",
            Img : ""
        },
        {
            name : "service name",
            Img : ""
        }
    ]
    let inlineHTML = "";

    for(const service of services.values()){
        inlineHTML += `<div class="serv-container">
            <div class="service-desc">
            <span>${service.name}</span>
            </div>
            <div class="service-img">
                <div class="service-img-cont">
                    <img alt="service-img" src="${service.Img}"/>
                </div>
            </div>
        </div>`;
    }
    targetCotainer.innerHTML = inlineHTML;
    
}
//docEventListener();
export default indexPageLoader;