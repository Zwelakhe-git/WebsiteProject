

function setTopBar(setInput){
    const tbCont = document.querySelector("#top-bar");

    if(!tbCont){
        console.log("Element top-bar not found. Cant insert content for Top bar");
        return;
    }

    tbCont.innerHTML = `
    <div class="top-bar-container">
            <div id="logo">
                <img alt="logo" type="image/jpg" width="50" height="50" src="/media/images/Konektem.png"/>
            </div>
            <div id="top-bar-content" class="flxDisp full-h">
            	<div class="container links search flxDisp">
                    <div class="search-bar flxDisp">
                        <input id="tb-inp-el" class="input no-outln no-bdr full-w" name='search' placeholder='Chache' />
                        <div id="tb-inp-div" class="input search-inp no-outln no-bdr full-w"><span>Chache</span></div>
                        <i class="fa-solid fa-magnifying-glass"></i>
                    </div>
                    <div class="social evenFlx">
                        <a href="https://www.facebook.com/Konektempageofficielle?mibextid=LQQJ4d"><i class="fa-brands fa-facebook"></i></a>
                        <a href="https://x.com/konektemtv?s=21"><i class="fa-brands fa-x-twitter"></i></a>
                        <a href="https://www.instagram.com/konektem?igsh=MTBsdWQ0dXl4ZXY5Mg=="><i class="fa-brands fa-instagram"></i></a>    
                        <a href="https://www.threads.net/@konektem"><i class="fa-brands fa-threads"></i></a>
                        <a href="https://www.tiktok.com/@konektem?_t=8kUq55lp4Kc&_r=1"><i class="fa-brands fa-tiktok"></i></a>
                        <a href="https://youtube.com/@konektemtv?si=x489XTA1xyNVoXjw"><i class="fa-brands fa-youtube"></i></a>
                    </div>
                </div>
                ${setInput ? "" :
                `<div class="icon-container">
                    <ion-icon name="reorder-three-outline"  class="opts-icon"</ion-icon>
                </div>`}
            </div>
        </div>
    `
    // <i class="fa-solid fa-bars opts-icon"></i>

    setTimeout( () => {
        let optsIcon = document.querySelector(".opts-icon");
        if(!optsIcon){
            console.log("Options icon not found");
            return;
        }

        optsIcon.addEventListener("click", event => {
            const navPanel = document.querySelector("#nav-panel");
                if( !navPanel ){
                    console.log("nav-panel not found");
                    return;
                }

                navPanel.classList.toggle("open");
                if(navPanel.classList.contains("open")){
                    navPanel.style.display = "block";
                    navPanel.style.maxHeight = `${navPanel.scrollHeight}px`;
                }
                else{
                    navPanel.style.maxHeight = "0px";
                    setTimeout(() => {
                        navPanel.style.display = "none";
                    }, 350);
                }
            });
    }, 350)
    
    return;
}

function setFooter(){
    let footer = document.createElement("footer");
    footer.id = "footer";
    footer.innerHTML = `
<div class="container">
    <div class="footer-content">
        <div class="footer-section">
            <h3>Konsenan KonektemNews</h3>
            <p>N ap bay nouvèl ki egzak ak alè soti toupatou nan mond lan. Misyon nou se enfòme, edike, epi angaje lektè nou yo.</p>
        </div>
        <div class="footer-section">
            <h3>Categories</h3>
            <ul>
                <li><a href="#">Politik</a></li>
                <li><a href="#">Biznis</a></li>
                <li><a href="#">Teknoloji</a></li>
                <li><a href="#">Spo</a></li>
                <li><a href="#">Divetisman</a></li>
            </ul>
        </div>
        <div class="footer-section">
            <h3>Konekte avek nou</h3>
            <div class="social-icons">
                <a href="#"><i class="fab fa-facebook"></i></a>
                <a href="#"><i class="fab fa-twitter"></i></a>
                <a href="#"><i class="fab fa-instagram"></i></a>
                <a href="#"><i class="fab fa-linkedin"></i></a>
            </div>
        </div>
        <div class="footer-section">
            <h3>Abòne ak Bilten Nouvel la</h3>
            <p>Rete enfòme ak dènye nouvèl ak istwa nou yo lè ou abòne ak bilten enfòmasyon nou an.</p>
            <form>
                <input type="email" placeholder="Your Email Address" style="padding:10px; width:100%; margin-top:10px; border-radius:4px; border:none;">
                <button type="submit" style="background:#ffcc00; color:#1a4b8c; border:none; padding:10px 15px; margin-top:10px; border-radius:4px; font-weight:bold; cursor:pointer;">Abone</button>
            </form>
        </div>
    </div>
    <div class="copyright">
        <p>&copy; 2025 KonektemNews. All rights reserved.</p>
    </div>
</div>`;
    document.body.insertAdjacentElement("beforeend", footer);
}

function setNavPanel(){
    let navPanel = document.querySelector("#nav-panel");
    if(!navPanel){
        console.log("setNavPanel: container not found");
        return;
    }
    navPanel.innerHTML = `
    <div id="nav" class="no-ovrflw">
            <a tabindex="0" class="bdr-10 nav-link" href="/?p=actuality">
                <ion-icon name="calendar-clear-outline"></ion-icon>
              <span>Aktyalite</span>
            </a>
            <a tabindex="0" class="bdr-10 nav-link" href="/?p=music">
                <ion-icon name="bar-chart-outline"></ion-icon>
                <span>Palmares mizik e videyo</span>
            </a>
            <a tabindex="0" class="bdr-10 nav-link" href="/?p=services">
                <i class="fa-solid fa-satellite-dish"></i>
                <span>Sevis</span>
            </a>
            <a tabindex="0" class="bdr-10 nav-link" href="/?p=streaming">
                <ion-icon name="radio-outline"></ion-icon>
                <span>Striming</span>
            </a>
            <a tabindex="0" class="bdr-10 nav-link" href="/?p=events">
                <ion-icon name="search-outline"></ion-icon>
                <span>Events</span>
            </a>
            <a tabindex="0" class="bdr-10 nav-link" href="/?p=emailsubscribtion">
                <i class="fa-regular fa-thumbs-up"></i>
                <span>Abone</span>
            </a>
            <a tabindex="0" class="bdr-10 nav-link">
            	<ion-icon name="search-outline"></ion-icon>
              	<span>Chache</span>
            </a>
            <a tabindex="0" class="bdr-10 nav-link" href="/">
                <span>Main page</span>
            </a>
        </div>`;
}

// global variables
let innerW = window.innerWidth;
let outerW = window.outerWidth;
let resizeTimer = null;
let currentDisplay = innerW <= 768 ? "mobile" : "desktop";
let indexContentLoaded = false;

document.addEventListener("DOMContentLoaded", () => {
    
     let topBarstyleLink = document.createElement("link");
    topBarstyleLink.rel = "stylesheet";
    topBarstyleLink.href = "/experimental/CSS/topBar.css";
    document.head.appendChild(topBarstyleLink);
    topBarstyleLink.onload = () => {
        setTopBar(innerW <= 768 ? false : true );
    }

    let navPanelstyleLink = document.createElement("link");
    navPanelstyleLink.rel = "stylesheet";
    navPanelstyleLink.href = "/CSS/navpanelstyle.css";
    document.head.appendChild(navPanelstyleLink);
    navPanelstyleLink.onload = () => {
        setNavPanel();
    }
    
    let footerStylelink = document.createElement("link");
    footerStylelink.rel = "stylesheet";
    footerStylelink.href = "/experimental/CSS/footerStyle.css";
    document.head.appendChild(footerStylelink);
    footerStylelink.onload = () => {
        setFooter();
    }
})

function handleWindowSizeChange(){
    innerW = window.innerWidth;

    if(innerW <= 768){
        if(currentDisplay !== "mobile"){
            setTopBar(false);
            currentDisplay = "mobile";
            console.log("mobile display")
        }
    }
    else{
        if(currentDisplay !== "desktop"){
            setTopBar(true);
            currentDisplay = "desktop";
        }
    }
}

window.addEventListener("resize", () => {
    clearTimeout(resizeTimer);
    resizeTimer = setTimeout(() =>{
        handleWindowSizeChange();
    } , 350);
});



