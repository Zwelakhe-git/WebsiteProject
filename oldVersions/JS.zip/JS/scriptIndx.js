import {setEventHandlers} from './audScript.js'
import slideContainer from './bottomscroll.js'

const scriptIndx = () => {
    const headDiv = document.querySelector("#head");

    headDiv.innerHTML += `<a href="" class="link no-dec">
        <span>see all</span>
        <ion-icon name="chevron-forward-outline"></ion-icon>
      </a>`;
    setScrollButtons(headDiv);

    if(window.innerWidth <= 768){
        setSubscriptionPanel(true, "btm", true);
        setTopBar(false);
    }
    else{
        setTopBar(true);
    }
  	
    setSecInfo();
    giveSecsClasses();
    stylemiddlePanelCharts();
    setRightPanel();
    setPartnersAnimation();
    bottomImageSlide();
    setEventHandlers();
	configureAbsConatinerSizes();
};

// fading head
function setFadingTitle(headDiv){
    const ess = document.createElement("div");
    ess.classList.add("flxDisp");
    ess.id = "fadingTitle";
    
    headDiv.insertAdjacentElement("afterbegin", ess);
    ess.innerHTML = ess.innerHTML = "<h2 class='no-margin'>ESSENTIALS</h2>";

    ess.style.marginBottom = "5px";
    ess.style.justifyContent = "center";
    
}

// scroll buttons
function setScrollButtons(headDiv){
    headDiv.querySelectorAll(".scroll-btn").forEach(
        btn => {
            if(btn.classList.contains("right")){
                btn.innerHTML = "<ion-icon name='arrow-forward-outline' class='icon'></ion-icon>";
            }
            else if(btn.classList.contains("left")){
                btn.innerHTML = "<ion-icon name='arrow-back-outline' class='icon'></ion-icon>";
            }
            
        }
    );
}

// sections
function giveSecsClasses(){
    document.querySelectorAll(".app > div").forEach(
        secDiv => {
            if(secDiv.id !== "footer" && secDiv.id !== "top-bar"){
                if(secDiv.id !== "head" && secDiv.id !== "nav-panel"){
                    secDiv.classList.add("opt-width-marg", "margin-rl-1");
                }
                else if(secDiv.id === "navPanel"){
                    secDiv.classList.add("opt-width-nomarg");
                }
            }
        }
    );
}
function bottomImageSlide(){
  let imgUrls = [
    {
      mime_type : "image/jpeg",
      src : "/media/images/bottom/IMG_4657.JPG.jpg"
    },
    {
      mime_type : "image/jpeg",
      src : "/media/images/bottom/IMG_4658.JPG.jpg"
    },
    {
      mime_type : "image/jpeg",
      src : "/media/images/bottom/IMG_4659.JPG.jpg"
    },
    {
      mime_type : "image/jpeg",
      src : "/media/images/bottom/IMG_4656.JPG.jpg"
    },
    {
      mime_type : "image/jpeg",
      src : "/media/images/bottom/IMG_4660.JPG.jpg"
    },
    {
      mime_type : "image/jpeg",
      src : "/media/images/bottom/IMG_4661.JPG.jpg"
    },
    {
      mime_type : "image/jpeg",
      src : "/media/images/bottom/IMG_4662.JPG.jpg"
    },
      {
      mime_type : "image/jpeg",
      src : "/media/images/bottom/IMG_4664.JPG.jpg"
    },
      {
      mime_type : "image/jpeg",
      src : "/media/images/bottom/IMG_4665.JPG.jpg"
    },
      {
      mime_type : "image/jpeg",
      src : "/media/images/bottom/IMG_5227.JPG.jpg"
    },
   {
      mime_type : "image/jpeg",
      src : "/media/images/bottom/IMG_5244.JPG.jpg"
    },
   {
      mime_type : "image/jpeg",
      src : "/media/images/bottom/IMG_5245.JPG.jpg"
    },
      
  ]
  let linkTag = document.createElement("link");
    linkTag.rel = "stylesheet";
    linkTag.type = "text/css";
    linkTag.href = "/CSS/bottomScrollstyle.css";
    document.head.appendChild(linkTag);
  let container = document.querySelector(".bottom-slide");
  if(!container){
    console.log("bottomImageSlide: container not found");
    return;
  }
  let inlineHtml = "";
  imgUrls.forEach(imgObj => {
    inlineHtml += `
    <div class="slide-container">
      <img type="${imgObj.mime_type}" src="${imgObj.src}"/>
    </div>`;
    
  });
    
    setTimeout(() => {
        container.innerHTML = inlineHtml;
        slideContainer()
    }, 350);

}

// top bar
function setTopBar(setInput){
    const tbCont = document.querySelector("#top-bar-content");

    if(!tbCont){
        console.log("Element top-bar-content not found. Cant insert content for Top bar");
        return;
    }

    tbCont.innerHTML = `
    <div class="container links search flxDisp">
        <div class="search-bar flxDisp">
            ${setInput ? 
                `<input name='search' placeholder='Search' class="input no-outln no-bdr full-w" />`:
                `<div class="input search-inp no-outln no-bdr full-w"><span>Search</span></div>`
            }
            <i class="fa-solid fa-magnifying-glass"></i>
        </div>
        <div class="social evenFlx">
            
            <a href="https://www.facebook.com/Konektempageofficielle?mibextid=LQQJ4d">
            	<i class="fa-brands fa-facebook"></i>
            </a>
            
            <a href="https://x.com/konektemtv?s=21">
            	<i class="fa-brands fa-x-twitter"></i>
            </a> 
            <a href="https://www.instagram.com/konektem?igsh=MTBsdWQ0dXl4ZXY5Mg==">
            	<i class="fa-brands fa-instagram"></i>
            </a>
            
            <a href="https://www.threads.net/@konektem>
            	<i class="fa-brands fa-threads"></i>
            </a>
            
            <a href="https://www.tiktok.com/@konektem?_t=8kUq55lp4Kc&_r=1">
            	<i class="fa-brands fa-tiktok"></i>
            </a>
            
            <a href="https://youtube.com/@konektemtv?si=x489XTA1xyNVoXjw">
            	<i class="fa-brands fa-youtube"></i>
            </a>
        </div>
    </div>
    ${setInput ? "" :
    `<div class="icon-container">
    	<ion-icon name="reorder-three-outline"  class="opts-icon"></ion-icon>
    </div>`}`
    //<i class="fa-solid fa-bars opts-icon"></i>

    setTimeout( () => {
        let optsIcon = document.querySelector(".opts-icon");
        if(!optsIcon){
            console.log("Options icon not found");
            return;
        }

        optsIcon.addEventListener("click", event => {
            const navPanel = document.querySelector("#nav-panel");
                if( !navPanel ){
                    console.log("nav-panel not found");
                    return;
                }

                navPanel.classList.toggle("open");
                if(navPanel.classList.contains("open")){
                    navPanel.style.display = "block";
                    navPanel.style.maxHeight = `${navPanel.scrollHeight}px`;
                }
                else{
                    navPanel.style.maxHeight = "0px";
                    setTimeout(() => {
                        navPanel.style.display = "none";
                    }, 350);
                }
            });
    }, 350)
    
    return;
}


// section info
function setSecInfo(){
    document.querySelectorAll(".section-info h1").forEach(
        heading => {
            heading.classList.add("no-margin");
        }
    );
}

function configureAbsConatinerSizes(){
  let newsarticles = document.querySelector(".articles");
  let firstArticleItem = document.querySelector(".artcl-itm");
  if(!newsarticles || !firstArticleItem){
    console.log("Error: news articles container or article items not found. using default height");
    let defaultHeight = "122px";
    newsarticles.style.minHeight = defaultHeight;
    return;
  }
  let artclItemStyles = window.getComputedStyle(firstArticleItem);
  let optHeight = artclItemStyles.height;
  optHeight += artclItemStyles.paddingTop + artclItemStyles.paddingBottom;

  newsarticles.style.height = optHeight;
}

function stylemiddlePanelCharts(){
    // installing classes
    document.querySelectorAll(".music-track p").forEach( p => {
        p.classList.add("no-margin");
    })
    
    document.querySelectorAll(".music-track").forEach( p => {
        p.classList.add("flxDisp");
    })
    document.querySelectorAll(".audio-charts").forEach( p => {
        p.classList.add("flxDisp");
    })
}

function setRightPanel(){
    // right panel
    const rpDiv = document.querySelector("#link-portrait-video");
    rpDiv.classList.add("flxDisp");

    let rpCont =  `<div class="vid-container">
    <div id="rp-vid-container" class="html5-vid"></div>
    </div>`;
    rpDiv.innerHTML += rpCont;
}

// subscription
function setSubscriptionPanel(vidBG, pos, showTitle){
    const div = document.createElement("div");
    div.id = `sub-section-${pos}`;
    //"opt-width-marg","margin-rl-1"
    div.classList.add("flxDisp");
    let inlineHtml = `${ showTitle ? `<div class="section-info">
        <a href="/emailSubPage.html"><h1>ABONE</h1></a>
        </div>` : ""
        }
        <div class="sub flxDisp full-w-h" ${pos === "top" ? "style='background-color: #d2cccc; border-radius: 10px'" : ""}>
        ${vidBG ? `<div class="sub-bg flxDisp full-w-h">
            <video class="html-bg-vid full-w-h"
             type="video/mp4" src="/media/videos/file.mp4" 
              
              autoPlay
              muted
              loop>
            </video>
        </div>` : ""}
        <div class="flxDisp contnform">
            <div class="sub-text flxDisp">
                <p class="p-big">
                    Abone pou resevwa kontni eksklizif nou yo.
                </p>
                <p class="p-sml">
                "Kelkeswa gwose biznis ou a oswa domen w ap evolye a, 
                    nou gen konpetans ak ekspetiz nesese pou n ede
                    w reyisi nan mond dijital la."
                </p>
            </div>
            <form class="subform flxDisp" method="POST">
                <div class="sub-inpF flxDisp">
                    <label>Email*</label>
                    <input type="email" name="clientemail" required=""/>
                </div>
                <div class="mail-sub flxDisp">
                    <input type="checkbox" name="emailSub"/>
                    <label for="emailSub">yes, subscribe me to your newsletters</label>
                </div>
                <div class="form-btns flxDisp">
                    <button type="send" id="emailSndBtn" class="full-w">Send</button>
                </div>
            </form>
        </div>
      </div>
      
      <div class="gap" id="sub-gap-${pos}"></div>`;

      div.innerHTML = inlineHtml;

    switch(pos){
        case "top":
            let partnersDiv = document.querySelector("#events-section");
            
            if(partnersDiv){
                try{
                    document.body.insertBefore(div, partnersDiv);
                }catch(error){
                    console.log(error.message);
                }
            }
            else{
                console.log("partners div not found");
            }
            break;
        case "btm":
            let eventsDiv = document.querySelector("#partners-panel");
            if(eventsDiv){
                try{
                    eventsDiv.parentElement.insertBefore(div, eventsDiv);
                }catch(error){
                    console.log(error.message);
                }
            }
            else{
                console.log("events div not found");
            }
            
            break;
    }
}

function setPartnersAnimation(){
    // partners
    let inlineHtml = `<div id="partners-list" class="partners">
    <img src="/media/images/partners/LE PLAZA.JPG" alt="Le Plaza Hotel">
    <img src="/media/images/partners/shekina_.JPG" alt="Shekinah FM">
    <img src="/media/images/partners/CHOUKOUN.JPG" alt="Choucoune">
    <img src="/media/images/partners/MD.JPG" alt="Mairie de Delmas">
    <img src="/media/images/partners/NINA.JPG" alt="Nina Hairstyling">
    </div>`;

    document.querySelector("#partners-panel").innerHTML += inlineHtml;

}

export default scriptIndx;