function promptUserToSub(){
    let regForm = `
    <div class="btn-div blu">SUBSCRIBE</div>
    <div class="btn-div grn">LOGIN</div>`;
    let regPage = document.createElement("div");
    regPage.id = "reg-page";
    regPage.innerHTML = regForm;
    let bodyContainer = document.querySelector("#body");
    if(!bodyContainer){
        bodyContainer = document.body;
    }
    bodyContainer.appendChild(regPage);
}

async function registrationForm(){
    let regForm = `
    <form id="regForm">
    <div class="field">
        <label>username</label>
        <input type="text" name="login" placeholder="name" required/>
    </div>
    <div class="field">
        <label>email</label>
        <input type="email" name="email" placeholder="email" required/>
    </div>
    <div class="field">
        <label>Password</label>
        <input name="password" type="password" placeholder="password" required/>
    </div>
    <div class="google-login-container">
        <div class="divider">
            <span>Or continue with</span>
        </div>
        <button type="button" id="google-register-btn" class="google-login-btn">
            <i class="fa-brands fa-google google-icon"></i>
            <span>Continue with Google</span>
        </button>
    </div>
    <div controls>
        <button type="button" id="send-btn">subscribe</button>
        <button type="button" id="login-btn">already have an account</button>
        <button type="button" id="cancel-btn">Cancel</button>
    </div>
    </form>`;
    let regPage = document.createElement("div");
    regPage.id = "reg-page";
    regPage.innerHTML = regForm;
    let bodyContainer = document.querySelector("#body");
    if(!bodyContainer){
        bodyContainer = document.body;
    }
    bodyContainer.appendChild(regPage);
    setTimeout(()=>{
        let cancelBtn = document.querySelector("#cancel-btn");
        let sendBtn = document.querySelector("#send-btn");
        let loginBtn = document.querySelector("#login-btn");
        let googleRegisterBtn = document.querySelector("#google-register-btn");
        
        if(!cancelBtn || !sendBtn || !loginBtn || !googleRegisterBtn){
            console.log("insertRegForm: control buttons not found");
            return;
        }
        
        // Google registration
        googleRegisterBtn.addEventListener('click', async () => {
            googleRegisterBtn.disabled = true;
            googleRegisterBtn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i><span>Loading...</span>';
            
            try {
                let response = await fetch('/php/dbReader.php?q=googleAuthUrl');
                let data = await response.json();
                
                if (data.auth_url) {
                    window.location.href = data.auth_url;
                } else if (data.error) {
                    throw new Error(data.error);
                } else {
                    throw new Error('No authentication URL received from server');
                }
            } catch (error) {
                console.error('Google registration error:', error);
                let errorMessage = 'Google authentication is not available at the moment.';
                
                if (error.message.includes('not configured') || error.message.includes('configuration missing')) {
                    errorMessage = 'Google authentication is not configured. Please contact administrator.';
                }
                
                alert(errorMessage);
                
                // Reset button
                googleRegisterBtn.disabled = false;
                googleRegisterBtn.innerHTML = '<i class="fa-brands fa-google google-icon"></i><span>Continue with Google</span>';
            }
        });
        
        loginBtn.addEventListener('click', ()=>{
            accessAuthentification();
        })
        cancelBtn.addEventListener("click", ()=>{
            bodyContainer.removeChild(regPage);
        });

        sendBtn.addEventListener("click", async () => {
            let form = document.querySelector("#regForm");
            if(!form){
                console.log("form sendBtn: form not found");
                return;
            }
            let formData = new FormData(form);
            for(const [key, value] of formData.entries()){
                if(value.length === 0){
                    alert("missing field: " + key);
                    return;
                }
            }

            try{
                let result = await registerUser(formData);
                if(result){
                    redirectToStreamingPage();
                }
            }catch(error){
                console.log(error);
            }
        })
    }, 350);
}

async function accessAuthentification(strm_id){
    let accessForm = `
    <form id="accessForm">
    <h2>Enter your stream access information</h2>
    <div class="field">
        <label>login</label>
        <input type="text" name="login" placeholder="login" required/>
    </div>
    <div class="field">
        <label>Access key</label>
        <input type="text" name="accessKey" placeholder="accesskey" required/>
    </div>
    <div class="field">
        <label>Password</label>
        <input name="password" type="password" placeholder="password" required/>
    </div>
    <div class="google-login-container">
        <div class="divider">
            <span>Or continue with</span>
        </div>
        <button type="button" id="google-access-btn" class="google-login-btn">
            <i class="fa-brands fa-google google-icon"></i>
            <span>Continue with Google</span>
        </button>
    </div>
    <div class='controls'>
        <button type="button" id="send-btn">Watch</button>
        <button type="reset">clear</button>
        <button type="button" id="cancel-btn">Cancel</button>
    </div>
    <p>Don't have subscription key?<a href="/?p=payments&f=stream">Buy</a></p>
    </form>`;
    let regPage = document.createElement("div");
    regPage.id = "reg-page";
    regPage.innerHTML = accessForm;
    let bodyContainer = document.querySelector("#body");
    if(!bodyContainer){
        bodyContainer = document.body;
    }
    bodyContainer.appendChild(regPage);
    setTimeout(()=>{
        let cancelBtn = document.querySelector("#cancel-btn");
        let sendBtn = document.querySelector("#send-btn");
        let googleAccessBtn = document.querySelector("#google-access-btn");
        
        if(!cancelBtn || !sendBtn || !googleAccessBtn){
            console.log("insertRegForm: control buttons not found");
            return;
        }

        // Google authentication for stream access
        googleAccessBtn.addEventListener('click', async () => {
            googleAccessBtn.disabled = true;
            googleAccessBtn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i><span>Loading...</span>';
            
            try {
                let response = await fetch('/php/dbReader.php?q=googleAuthUrl');
                let data = await response.json();
                
                if (data.auth_url) {
                    // Store stream ID for redirect after Google auth
                    if (strm_id) {
                        sessionStorage.setItem('pending_stream_id', strm_id);
                    }
                    window.location.href = data.auth_url;
                } else if (data.error) {
                    throw new Error(data.error);
                } else {
                    throw new Error('No authentication URL received from server');
                }
            } catch (error) {
                console.error('Google access error:', error);
                let errorMessage = 'Google authentication is not available at the moment.';
                
                if (error.message.includes('not configured') || error.message.includes('configuration missing')) {
                    errorMessage = 'Google authentication is not configured. Please contact administrator.';
                }
                
                alert(errorMessage);
                
                // Reset button
                googleAccessBtn.disabled = false;
                googleAccessBtn.innerHTML = '<i class="fa-brands fa-google google-icon"></i><span>Continue with Google</span>';
            }
        });

        cancelBtn.addEventListener("click", ()=>{
            bodyContainer.removeChild(regPage);
        });

        sendBtn.addEventListener("click", async () => {
            let form = document.querySelector("#accessForm");
            if(!form){
                console.log("form sendBtn: form not found");
                return;
            }
            let formData = new FormData(form);
            for(const [key, value] of formData.entries()){
                if(value.length === 0){
                    alert("missing field: " + key);
                    return;
                }
            }

            try{
                let result = await grantAccess(formData);
                if(result){
                    redirectToStreamingPage(strm_id);
                    cancelBtn.click();
                }
            }catch(error){
                console.log(error);
            }
        })
    }, 350);
}

function redirectToStreamingPage(strm_id){
    getCurrentStreamKey(strm_id)
    .then( sk => {
        renderFrame(sk);
    }).catch( reason => {
        alert(reason.message);
    })
    
}

function getCurrentStreamKey(strm_id){
    return fetch('/php/dbReader.php?r=stream')
    .then( response => response.json())
    .then( streams => {
        let today = new Date().toISOString().split('T')[0];
        for(let i = 0; i < streams.length; ++i){
            if(streams[i].stream_date.split(' ')[0] === today && (streams[i].id === Number(strm_id) || !strm_id)){
                return streams[i].stream_key;
            }
        }
        throw new Error("No current streams for today");
    });
}

function renderFrame(streamkey){
    let root = document.querySelector('#root');
    let url = `https://try.antmedia.io/zwelakhemzwet/play.html?id=${streamkey}`;
    let container = document.createElement('div');
    container.classList.add('streamWin-container');
    container.innerHTML = `
        <div class="stream-win">
          <iframe sandbox="allow-scripts allow-same-origin allow-top-navigation allow-forms" id="stream-frame" src="${url}">
          </iframe>
        </div>
        <div class="btn stream-close-btn">
          <i class="fa-solid fa-circle-stop stop-btn"></i>
        </div>
      </div>`
    ;
    root.appendChild(container);
    setTimeout(()=>{
        let streamCancelBtn = document.querySelector('.stream-close-btn .stop-btn');
        streamCancelBtn.onclick = closeFrame;
    },100);
    document.body.style.overflow = 'hidden';
}

function closeFrame(){
    let root = document.querySelector('#root');
    let container = document.querySelector('.streamWin-container');
    root.removeChild(container);
    document.body.style.overflow = 'auto';
}

function popup(){
    let div = document.createElement('div');
    div.classList.add('pop-up-prompt');
    div.innerHTML = `
        <div class='pop-form'>
          <button type='button' onclick="window.location.href='/?p=payments'">
            PAY TO WATCH MORE
          </button>
          <p>already paid? <span class='undlr rd-clr pp-login-btn'>login</span></p>
          <div class="google-login-container">
            <div class="divider">
                <span>Or continue with</span>
            </div>
            <button type="button" class="google-login-btn pp-google-btn">
                <i class="fa-brands fa-google google-icon"></i>
                <span>Continue with Google</span>
            </button>
          </div>
          <button type='button' class='rd-bg pp-close-btn'
          style="background-color: red">close</button>
        </div>`;
    return div;
}

// Check for Google auth success on page load for streaming
function checkGoogleAuthForStreaming() {
    const urlParams = new URLSearchParams(window.location.search);
    const googleSuccess = urlParams.get('google_success');
    const googleError = urlParams.get('google_error');
    const user = urlParams.get('user');
    
    if (googleSuccess === '1' && user) {
        // Get pending stream ID from session storage
        const pendingStreamId = sessionStorage.getItem('pending_stream_id');
        
        // Update UI to show logged in state
        window.currentUser = user;
        
        // Show success message
        alert('Successfully logged in with Google!');
        
        // Clean URL
        window.history.replaceState({}, document.title, window.location.pathname);
        
        // Redirect to streaming if there was a pending stream
        if (pendingStreamId) {
            sessionStorage.removeItem('pending_stream_id');
            setTimeout(() => {
                redirectToStreamingPage(pendingStreamId);
            }, 1000);
        }
    }
    
    if (googleError === '1') {
        const message = urlParams.get('message') || 'Google authentication failed';
        alert(message);
        
        // Clean URL
        window.history.replaceState({}, document.title, window.location.pathname);
    }
}

// this handler is currently not used
async function streamPlayHandlerasync(playBtn){
    let streamid = playBtn.dataset.streamid;
    if(streamid === 'none'){
        alert('Stream is Currently offline');
        return;
    }
    let streamkey = await getCurrentStreamKey(streamid);
    renderFrame(streamkey);

    setTimeout(()=>{
        try{
            let container = document.querySelector('.streamWin-container');
            let frame = container.querySelector('iframe');
            let pp_win = popup();

            document.body.appendChild(pp_win);
            setTimeout(()=>{
                let form = pp_win.querySelector('.pop-form');
                let closePPBtn = pp_win.querySelector('.pp-close-btn');
                let loginPPBtn = pp_win.querySelector('.pp-login-btn');
                let googlePPBtn = pp_win.querySelector('.pp-google-btn');
                
                form.classList.add('open');
                frame.style.filter = 'blur(5px)';

                // Google login in popup
                googlePPBtn.addEventListener('click', async () => {
                    try {
                        let response = await fetch('/php/dbReader.php?q=googleAuthUrl');
                        let data = await response.json();
                        
                        if (data.auth_url) {
                            // Store stream ID for redirect after Google auth
                            sessionStorage.setItem('pending_stream_id', streamid);
                            window.location.href = data.auth_url;
                        }
                    } catch (error) {
                        console.error('Google login error:', error);
                        alert('Google authentication failed. Please try again.');
                    }
                });

                closePPBtn.onclick = ()=>{
                    form.classList.remove('open');
                    setTimeout(()=>{
                        document.body.removeChild(pp_win);
                        closeFrame();
                    },300);
                }

                loginPPBtn.onclick = ()=>{
                    form.classList.remove('open');
                    setTimeout(()=>{
                        document.body.removeChild(pp_win);
                        closeFrame();
                        accessAuthentification(streamid);
                    },300);
                }
            },100)
        } catch(error){
            console.log(error.message);
        }

    }, 5000);
}

export default function streamingReg(){
    // Check for Google auth on page load
    checkGoogleAuthForStreaming();
    
    let playBtn = document.querySelector(".play-button");
    let watchBtn = document.querySelectorAll(".watch-link");

    if(!playBtn){
        console.log("play button not found");
        return;
    }
    
    if(watchBtn.length > 0){
        watchBtn.forEach(btn => {
            btn.addEventListener('click', (e)=>{
                accessAuthentification(btn.dataset.streamid);
            });
        })
    }
    
    playBtn.addEventListener('click', async ()=>{
        let streamid = playBtn.dataset.streamid;
        if(streamid === 'none'){
            alert('Stream is Currently offline');
            return;
        }
        let streamkey = await getCurrentStreamKey(streamid);
        renderFrame(streamkey);

        setTimeout(()=>{
            try{
                let container = document.querySelector('.streamWin-container');
                let frame = container.querySelector('iframe');
                let pp_win = popup();

                document.body.appendChild(pp_win);
                setTimeout(()=>{
                    let form = pp_win.querySelector('.pop-form');
                    let closePPBtn = pp_win.querySelector('.pp-close-btn');
                    let loginPPBtn = pp_win.querySelector('.pp-login-btn');
                    let googlePPBtn = pp_win.querySelector('.pp-google-btn');
                    
                    form.classList.add('open');
                    frame.style.filter = 'blur(5px)';

                    // Google login in popup
                    googlePPBtn.addEventListener('click', async () => {
                        try {
                            let response = await fetch('/php/dbReader.php?q=googleAuthUrl');
                            let data = await response.json();
                            
                            if (data.auth_url) {
                                // Store stream ID for redirect after Google auth
                                sessionStorage.setItem('pending_stream_id', streamid);
                                window.location.href = data.auth_url;
                            }
                        } catch (error) {
                            console.error('Google login error:', error);
                            alert('Google authentication failed. Please try again.');
                        }
                    });

                    closePPBtn.onclick = ()=>{
                        form.classList.remove('open');
                        setTimeout(()=>{
                            document.body.removeChild(pp_win);
                            closeFrame();
                        },300);
                    }
                    
                    loginPPBtn.onclick = ()=>{
                        form.classList.remove('open');
                        setTimeout(()=>{
                            document.body.removeChild(pp_win);
                            closeFrame();
                            accessAuthentification(streamid);
                        },300);
                    }
                },100)
            } catch(error){
                console.log(error.message);
            }

        }, 5000);
    });
}

async function registerUser(data){
    const alertDiv = document.createElement('div');
    alertDiv.classList.append('alert', 'success', 'abs-pos');
    
}

async function grantAccess(formData){
    try{
        const response = await makeRequest("POST", '/php/streamAccess.php', formData);
        if(response.access === "granted"){
            return true;
        } else {
            alert(response.message);
            return false;
        }
    }catch(error){
        console.log(error);
        return false;
    }
}

function makeRequest(method, url, data){
    return new Promise((resolve, reject) => {
        var xmlHttp;
        if(window.ActiveXObject){
            xmlHttp = new ActiveXObject();
        }
        else{
            xmlHttp = new XMLHttpRequest();
        }
        xmlHttp.open(method, url, true);
        xmlHttp.responseType = "json";
        xmlHttp.onreadystatechange = function (){
            if(xmlHttp.readyState === 4){
                if(xmlHttp.status >= 200 && xmlHttp.status < 300){
                    var jsonResponse = xmlHttp.response;
                    resolve(jsonResponse);
                }
                else{
                    reject({
                        status: xmlHttp.status,
                        text: xmlHttp.statusText
                    });
                }
            }
        };

        xmlHttp.onerror = function (){
            reject({
                status: xmlHttp.status,
                text: xmlHttp.statusText
            });
            console.log("error when sending request");
        }

        xmlHttp.send(data);

    })
}

// Add CSS for Google login buttons
const googleStyles = `
.google-login-container {
    margin: 20px 0;
}

.divider {
    display: flex;
    align-items: center;
    margin: 20px 0;
    color: #666;
    font-size: 14px;
}

.divider::before,
.divider::after {
    content: '';
    flex: 1;
    border-bottom: 1px solid #ddd;
}

.divider span {
    padding: 0 10px;
}

.google-login-btn {
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 10px;
    width: 100%;
    padding: 12px;
    border: 1px solid #ddd;
    border-radius: 8px;
    background: white;
    color: #333;
    font-size: 16px;
    cursor: pointer;
    transition: all 0.3s ease;
    margin-bottom: 15px;
}

.google-login-btn:hover:not(:disabled) {
    background: #f5f5f5;
    border-color: #ccc;
    transform: translateY(-1px);
    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
}

.google-login-btn:disabled {
    opacity: 0.6;
    cursor: not-allowed;
}

.google-icon {
    color: #4285F4;
    font-size: 16px;
}

.fa-spin {
    animation: fa-spin 1s infinite linear;
}

@keyframes fa-spin {
    0% { transform: rotate(0deg); }
    100% { transform: rotate(360deg); }
}
`;

// Inject styles
const styleSheet = document.createElement('style');
styleSheet.textContent = googleStyles;
document.head.appendChild(styleSheet);

streamingReg();