export function setClickEventForLikeButtons(){
    let likeIcons = Array.from(document.querySelectorAll(".like-btn .media-ico"));
    if(!likeIcons){
        console.log("like icons not found");
        return;
    }
    likeIcons.forEach((icon => {
        icon.addEventListener("click", (event) => {
            icon.classList.toggle("clicked");
        })
    }));
}